#!/usr/bin/env python
# coding: utf-8

from graphviz import Digraph
import re
from copy import deepcopy

class Vertex:
    def __init__(self,key):
        self.id=key
        self.SFC_id=[]
        self.nf_id = []
        self.connectedTo={} # key:node (not id), value: dep
        self.core = 0
        self.match = []
        self.action = []
        self.con = []
        self.reg = {}
        self.SRAM = 0
        self.TCAM = 0
        self.ALU = 0
        self.stage = []

    
    def addNFID(self,nf_id):
        n_id =  's'+str(self.SFC_id[0])+'n'+str(nf_id)
        self.nf_id.append(n_id)
        
    def appendNFID(self,nf_id):
        self.nf_id.append(nf_id)
        
    def getStage(self):
        return self.stage
    
    def ifreg(self):
        # if has reg return 1  , otherwise return 0
        if(self.reg == {}):
            return 0
        else:
            return 1
    
    def getDep(self, node_id):
        for key, value in self.connectedTo.items():
            if key.id == node_id:
                return value
            else:
                print('ERROR, not this link betweet offering node and the node')
    
    def addSRAM(self, total):
        self.SRAM = total
        
    def addTCAM(self, total):
        self.TCAM = total
        
    def addALU(self, total):
        self.ALU = total
    
    def addNeighbor(self,nbr,weight=0):
        self.connectedTo[nbr]=weight
        
    def addSFCId(self,sfc_id):
        self.SFC_id.append(sfc_id)
        
    def addMatch(self,match):
        self.match.append(match)
    def addAction(self,action):
        self.action.append(action)
    def addCon(self,con):
        self.con.append(con)
    def addReg(self,reg_name, reg_list):
        self.reg[reg_name] = reg_list
        
    def addCore(self):
        self.core = 1
    def if_con_node(self):
        # 1 -> is con_node 0-> is not con_node
        if self.con == []:
            return 0
        else:
            return 1

    def getConnections(self):
        return self.connectedTo.keys()

    def getId(self):
        return self.id
    
    def getSFCId(self):
        return self.SFC_id
    
    def getWeight(self,nbr):
        return self.connectedTo[nbr]

class Graph:
    def __init__(self):
        self.vertList={}
        self.numVertices=0
        
    
    def get_all_link(self):
        link_list = []
        for i in self.vertList.values():
            if(i.connectedTo != {}):
                for j in list(i.connectedTo.keys()):
                    link_list.append([i.id, j.id])
        return link_list
    
    def sfc_id_search(self, node):
        #print('n:', node)
        #print(self.vertList[node].SFC_id)
        return deepcopy(self.vertList[node].SFC_id)
        
    def check_sfc_stage(self, sfc_id):
        stage_front = None
        stage_rear = None
        seq_list = self.topologic_sequence()
        for node in seq_list:
            SFC_id_list = self.vertList[node].SFC_id
            if(sfc_id in SFC_id_list):
                if(stage_front == None):
                    stage_front = min(self.vertList[node].stage)
                if(stage_rear == None):
                    stage_rear = max(self.vertList[node].stage)
                if(stage_front > min(self.vertList[node].stage)):
                    stage_front = min(self.vertList[node].stage)
                if(stage_rear < max(self.vertList[node].stage)):
                    stage_rear = max(self.vertList[node].stage)    
        if(stage_front == None or stage_rear == None):
            print('stage == None!!!!!!!!!!!!grapg.c')
        return stage_front, stage_rear
        
        
    def delete_nf_node(self, node_name):
        front_nodes = self.search_front_node(node_name)
        after_nodes = self.search_after_node(node_name)
        
        
    def check_nf_place(self, node_name, stage_range):
        if(stage_range[0] > stage_range[1]):
            #print('这里？')
            return False, -1, None
        # 查看在stage范围内是否有node_name部署
        seq_list = self.topologic_sequence()
        #print('node_name', node_name)
        for n_name in seq_list:
            try:
                node_shape_name = re.findall(r'(.+)@', n_name)[0]
            except:
                node_shape_name = n_name
            if(node_shape_name == node_name):
                
                flag = True
                # 在self.vertList[n_name].stage中所有的stage都必须满足
                for stage in self.vertList[n_name].stage:
                    if(stage_range[0] <= stage <= stage_range[1]):
                        # 找到了该node的部署位置，更新cfg
                        #return True, self.vertList[n_name].stage
                        None
                    else:
                        
                        flag = False
                if(flag == True):
                    return True, self.vertList[n_name].stage, n_name      
        #print('这里？2222')
        return False, -1, None
    
    def find_node_stage(self, sfc_id, node_name):
        # 给定SFCid, node_name，返回stage_List={stage:flag, ...}，同时
        # 如果flag=1表示重复，=0表示不重复，可以删除
        node_stage = {}
        seq_list = self.topologic_sequence()
        for n_name in seq_list:
            try:
                node_shape_name = re.findall(r'(.+)@', n_name)[0]
            except:
                node_shape_name = n_name
            if(node_shape_name == node_name):
                
                if(sfc_id in self.vertList[n_name].SFC_id):
                    for stage in self.vertList[n_name].stage:
                        if(len(self.vertList[n_name].SFC_id) == 1):
                            node_stage[stage] = 0
                        else:
                            node_stage[stage] = 1
        return node_stage
                    
                
    '''
    def find_sfc_info(self, sfc_id, move_range_front, move_range_rear):
        # 给定SFCid找到该SFC中所有node对应的stage,和所占用的stage范围
        # {node: stage}
        seq_list = self.topologic_sequence()
        sfc_stage_front = []
        sfc_stage_rear = []

        for node_name in seq_list:
            try:
                node_shape_name = re.findall(r'(.+)@', node_name)[0]
            except:
                node_shape_name = node_name
            if((node_shape_name in move_range_front) or move_range_front == []):
                #print('node_shape_name', node_shape_name)
                for nf_name in self.vertList[node_name].nf_id:
                    sfc_id_temp = re.findall(r's(.+)n',nf_name)[0]
                    #print('sfc_id_temp', sfc_id_temp)
                    if(sfc_id_temp == sfc_id):
                        sfc_stage_front.extend(self.vertList[node_name].stage)
            if((node_shape_name in move_range_rear)or move_range_rear == []):
                #print('node_shape_name', node_shape_name)
                for nf_name in self.vertList[node_name].nf_id:
                    sfc_id_temp = re.findall(r's(.+)n',nf_name)[0]
                    if(sfc_id_temp == sfc_id):
                        sfc_stage_rear.extend(self.vertList[node_name].stage)
        print('sfc_stage_front', sfc_stage_front)
        print('sfc_stage_front', sfc_stage_rear)
        if(sfc_stage_front == []):
            sfc_stage_front = [1]
        if(sfc_stage_rear == []):
            sfc_stage_rear = [max(self.vertList['end'].stage)]
        
        if(move_range_front!=[] and move_range_rear!=[]):
            sfc_stage_front_num = max(sfc_stage_front)+1
            sfc_stage_rear_num = min(sfc_stage_rear)-1
            if(sfc_stage_front_num>=sfc_stage_rear_num):
                print('sfc range 出错！！！！！！graph。c文件')
        elif(move_range_front==[] and move_range_rear!=[]):
            sfc_stage_front_num = min(sfc_stage_front)
            sfc_stage_rear_num = min(sfc_stage_rear)-1
            
        elif(move_range_front!=[] and move_range_rear==[]):
            sfc_stage_front_num = max(sfc_stage_front)+1
            sfc_stage_rear_num = max(sfc_stage_rear)
            
        elif(move_range_front == [] and move_range_rear == []):
            sfc_stage_front_num = min(sfc_stage_front)
            sfc_stage_rear_num = max(sfc_stage_rear)
        
        
        sfc_range = [sfc_stage_front_num, sfc_stage_rear_num]
        return sfc_range
    '''        
    
    def check_list_have_same_element(self, list1, list2):
        a = [x for x in list1 if x in list2]
        if(a == []):
            return False
        else:
            return True
    
    def check_dep_with_nodes(self, front_node, after_node):
        # 1.有condition连接
        
        if(self.if_dependency(front_node, after_node)):
            return True
        # 2.有field连接
        front_action_list = self.vertList[front_node].action
        front_match_list = self.vertList[front_node].match
        after_action_list = self.vertList[after_node].action
        after_match_list = self.vertList[after_node].match
        if(self.check_list_have_same_element(front_action_list, after_match_list)):
            
            return True
        if(self.check_list_have_same_element(front_action_list, after_action_list)):
            
            return True
        if(self.check_list_have_same_element(front_match_list, after_action_list)):
            
            return True
        return False
    
    def find_nf_node(self, nf_name_list_input, sfc_id):
        # sfc_id = 0 时用于临时比对的临时SFC
        # 输入一个nf的名字list，找到这个nf在SFC_Id中所有的node，
        # 返回有两个，一个list中包含node是这个nf独有的，一个是共享的node
        nf_node_list_share = []
        nf_node_list_not_share = []
        seq_list = self.topologic_sequence()
        node2nf_list = {}
        backup_dict = {}
        #print('nf_name_list_input', nf_name_list_input)
        for nf_name in nf_name_list_input:
            for node in seq_list:
                try:
                    node_shape_name = re.findall(r'(.+)@', node)[0]
                except:
                    node_shape_name = node
                if(node_shape_name == 'start' or node_shape_name == 'end'):
                    continue
                nf_name_list = self.find_nf_name(node_shape_name)
                
                sfc_id_list = self.find_sfc_id(node_shape_name)
                # 如果SFC_id大于1代表在合成时有多个table可以合成，也就是可以共享
                if(nf_name in nf_name_list and sfc_id_list.count(sfc_id)>1):                    
                    nf_node_list_share.append(node)                    
                    backup_dict[node] = nf_name
                    node2nf_list[node] = nf_name
                    
                if(nf_name in nf_name_list and sfc_id_list.count(sfc_id)==1):
                    nf_node_list_not_share.append(node)
                    node2nf_list[node] = nf_name
        #print('nf_node_list_share', nf_node_list_share)
        return nf_node_list_share, nf_node_list_not_share, node2nf_list, backup_dict


    def find_sfc_id(self, node_name):
        # 输入一个node，返回其SFCID
        sfc_id_list = []
        
        for nf_name in self.vertList[node_name].nf_id:
            sfc_id_list.append(re.findall(r's(.+)n',nf_name)[0])
        return sfc_id_list
    
    def find_nf_name(self, node_name):
        # 输入一个node，返回某个NF
        nf_name_list = []
        
        for nf_name in self.vertList[node_name].nf_id:
            nf_name_list.append(re.findall(r's\dn(.+)', nf_name)[0])
        return nf_name_list
    
    def vert_number(self):
        number = 0
        for i in self.vertList.keys():
            number = number + 1
        return number
    
    def addVertex(self, key, sfc_id, nf_id):
        self.numVertices=self.numVertices+1
        newVertex=Vertex(key)
        newVertex.addSFCId(sfc_id)
        newVertex.addNFID(nf_id)
        self.vertList[key]=newVertex
        return newVertex
    
    def del_start(self):
        # del start node and return after nodes
        after_list = []
        after_list = self.search_after_node('start')
        
    def if_dependency(self,v_id, w_id):
        for w,dep in self.vertList[v_id].connectedTo.items():
            if w.id == w_id:
                if(self.vertList[v_id].connectedTo[w] == 1):
                    return 1
                else:
                    return 0
    def add_dependency(self, v_id, w_id):
        for w,dep in self.vertList[v_id].connectedTo.items():
            if w.id == w_id:
                self.vertList[v_id].connectedTo[w] = 1
                
    def update_dependency(self):
        node_list = self.topologic_sequence()
        for node in node_list:    
            if(self.vertList[node].if_con_node()==1 or node == 'start'):
                # con_node
                for w,dep in self.vertList[node].connectedTo.items():
                    self.vertList[node].connectedTo[w] = 1
            else:
                # non condiction node
                node_action_list = self.vertList[node].action
                after_node_list = self.search_after_node(node)
                for after_node in after_node_list:
                    for node_action in node_action_list:
                        if ((node_action in self.vertList[after_node].action) or (node_action in self.vertList[after_node].match)):
                            self.add_dependency(node, after_node)
    def del_all_stage(self):
        for key in self.vertList.keys():
            self.vertList[key].stage = []
    def del_node(self, node_name):
        if(node_name not in list(self.vertList.keys())):
            print('not such node, delete failed')
        else:
            del self.vertList[node_name]
        
    def addNode(self, node, node_new_id=''):
        if(node.id in self.vertList.keys() and node_new_id == ''):
            print('key of adding node already being in the graph!!!!!!!!!!!!!!')
            print('node.id:',node.id)
        else:
            #add node
            if(node_new_id==''):
                self.numVertices=self.numVertices+1
                self.vertList[node.id]=node
            else:
                self.numVertices=self.numVertices+1
                self.vertList[node_new_id]=node
                node.id = node_new_id
    
    def ifemptynode(self, node_id1, node_id2):
        # 0 empty 
        node_list = self.search_after_node(node_id1)
        if node_id2 in node_list:
            return 0
        else:
            return 1
    
    def find_dep_node(self, node_id):
        #after_nodes = self.search_after_node(node_id)
        result = []       
        for node_name, value in self.vertList[node_id].connectedTo.items():
            if(value == 1):
                result.append(node_name.id)
        return result
    
    def search_node_from_SFCID(self, sfc_id):
        result_list = []
        for key in self.vertList.keys():
            if(sfc_id in self.vertList[key].SFC_id):
                result_list.append(key)
        return result_list
    
    def search_front_node(self, node_id):
        front_node = []
        for node in self.vertList.values():
            for next_node in node.connectedTo.keys():
                if next_node.id == node_id:
                    front_node.append(node.id)
        return front_node
    
    def search_front_node_max_stage(self, node_id):
        front_node = self.search_front_node(node_id)
        stage = 0
        stage_list = []
        for node_i in front_node:
            if(self.vertList[node_i].stage != []):
                stage_list.append(max(self.vertList[node_i].stage))
        stage = max(stage_list)
        return stage
    
    def search_after_node(self, node_id):
        after_node = []
        for ii in self.vertList[node_id].connectedTo.keys():
            after_node.append(ii.id)
        return after_node
    
    def search_all_after_node(self, node_id):
        all_after_node = []
        temp_node = [node_id]
        while(temp_node != []):
            cur_node = temp_node.pop(0)
            after_node_list = self.search_after_node(cur_node)
            temp_node = temp_node + after_node_list
            for node in after_node_list:
                if(node not in all_after_node):
                    all_after_node.append(node)
        return all_after_node
    
    def register_search(self):
        reg_list = []
        for v_key in self.vertList.values():
            if(v_key.reg != []):
                for i in v_key.reg.keys():
                    reg_list.append(i)
        return reg_list
    
    
    
    def after_dependency(self, node_id):
        dependency_list = []
        node_list = self.node_search(node_id, 1)
        for i in node_list:
            dependency_temp = self.node_dependency(i)
            for j in dependency_temp:
                dependency_list.append(j)
        return dependency_list
    
    def front_dependency(self, node_id):
        dependency_list = []
        node_list = self.node_search(node_id, 0)
        for i in node_list:
            dependency_temp = self.node_dependency(i)
            for j in dependency_temp:
                dependency_list.append(j)
        return dependency_list
    
    def node_dependency(self, node_id):
        dependency_list = []
        for field_m in self.vertList[node_id].match:
            dependency_list.append(field_m)
        for field_a in self.vertList[node_id].action:
            dependency_list.append(field_a)  
        return dependency_list
    
    def node_search(self, node_id, flag):
        # flag = 0 front search 1 after search
        node_list= self.topologic_sequence()
        if(flag == 1):
            while(node_list):
                node_temp = node_list.pop(0)
                if(node_temp == node_id):
                    node_list.insert(0, node_temp)
                    return node_list
            print('search error')
        
        elif(flag == 0):
            node_list_res = []
            for i in node_list:
                if i != node_id:
                    node_list_res.append(i)
                else:
                    return node_list_res
        else:
            None
        
    def modifyVertexId(self,key_id_old,key_id_new):
        
        self.vertList[key_id_new] = self.vertList[key_id_old]
        del self.vertList[key_id_old]
        self.vertList[key_id_new].id = key_id_new
        
    
    def getVertex(self,n):
        if n in self.vertList:
            return self.vertList[n]
        else:
            return None

    def __contains__(self,n):
        return n in self.vertList

    def addEdge(self,f,t,cost=0):
        # f,t -> id
        if f not in self.vertList:
            nv=self.addVertex(f)
        if t not in self.vertList:
            nv=self.addVertex(t)
        self.vertList[f].addNeighbor(self.vertList[t],cost)

    def getVertices(self):
        return self.vertList.keys()

    def __iter__(self):
        return iter(self.vertList.values())
    
    def getOrder(self):        
        order_list = [] 
        for key in self.vertList.keys():
            order_list.append(key)

        for i in self:
            for key in i.connectedTo.keys():
                try:
                    order_list.remove(key.id)
                except:
                    None
            if(len(order_list)<1):
                print("error! there has loop in the graph")
        return order_list

    def topologic_sequence(self):
        graph_ingress = self.getOrder()
        graph_order = []
        topo_queue = []
        for i in graph_ingress:
            graph_order.append(i)
            topo_queue.append(i)
        while topo_queue:
            #print('topo_queue', topo_queue)
            v_id = topo_queue.pop(0)
            
            if(v_id not in graph_order):
                graph_order.append(v_id)
            w = []
            
            for key in self.vertList[v_id].connectedTo:
                access_flag = 0
                front_node_list = self.search_front_node(key.id)
                for front_node in front_node_list:
                    if front_node not in graph_order:
                        access_flag = 1             
                if(access_flag == 0):
                    w.append(key.id) 
            for i in w:
                if(i not in topo_queue):
                    topo_queue.append(i)
        return graph_order

    def dependency_dict(self):
        graph_order = self.topologic_sequence()
        seq_dict = {}
        n = 1
        for i in range(len(graph_order)):
            if(i == 0):
                seq_dict[graph_order[i]] = 1
                continue
            else:
                n_temp = 0
                node_temp = ''
                front_node_list = self.search_front_node(graph_order[i])
                for front_node in front_node_list:
                    # 找到stage最大的前一个节点
                    if(seq_dict[front_node]>n_temp):
                        n_temp = seq_dict[front_node]
                        node_temp = front_node
                # 判断该节点是否有依赖性，如果有就加1，没有不加
                if(node_temp == ''):
                    print('can not find a front node')
                    return 0
                plus1_flag = 0
                conne_list = self.vertList[node_temp].connectedTo
                for i_key,i_value in conne_list.items():
                    if (i_key.id == graph_order[i]):
                        plus1_flag = i_value      
                seq_dict[graph_order[i]] = n_temp + plus1_flag
                
        # 按照值的顺序排列
        seq_dict = sorted(seq_dict.items(),key=lambda x:x[1],reverse=False)
        # 构造 依赖数组D                 
        D = [0]
        nn = 0
        value_temp = 0
        for i in seq_dict:    
            value = i[1]
            if(nn == 0):
                nn = nn + 1
                value_temp = value
                continue
            else:
                if(value > value_temp):
                    D.append(1)
                else:
                    D.append(0)
                value_temp = value
        graph_order = []
        for key in seq_dict:
            graph_order.append(key[0])
        
        return graph_order, D
    
    def del_graph(self):
        del self.vertList
            
    
    
        
                
                
        
        
        
        
