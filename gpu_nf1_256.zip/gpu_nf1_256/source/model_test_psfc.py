# -*- coding: utf-8 -*-

from topology.topology import Topology
from rl.rl_main import RL

#from spinup import vpg_pytorch
def init_topo_from_file(topo_file_path):
    sfc_num = 5
    topo = Topology(sfc_num)
    topo.topo_preprocess(topo_file_path)
    return topo

#topo_file_path = 'abovenet.csv'
topo_file_path = 'node4.csv'
#model_path = '1655706971_GCN_1024'
rl_solve = RL(topo=init_topo_from_file(topo_file_path),\
              num_gnn_layer=2,model_path=model_path)
rl_solve.run_training()

