import numpy as np
import scipy.signal, math
from gym.spaces import Box, Discrete

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.normal import Normal
from torch.distributions.categorical import Categorical
from torch.nn.parameter import Parameter

import pdb, functools
import logging
import random

max_tbl_num = 24
ip_fea = 2 # lat bw
stage_fea = 3 # tcam sram occp redunt
tbl_fea = 4

def mlp(sizes, activation, dropout_flag=False, dropout=0.5, output_activation=nn.Identity):
    layers = []
    # mlp([feature_num*ip_node_num（=observation_space.shape[0]）]
    # + list(hidden_sizes=256) + [act_num=action_space.n], activation)
    #print('sizes:', sizes)
    for j in range(len(sizes)-1):
        act = activation if j < len(sizes)-2 else output_activation
        #print('j', j)
        #print('size:', sizes[j])
        #print('size:', sizes[j+1])
        
        if dropout_flag:
            layers += [nn.Linear(sizes[j], sizes[j+1]), act(), nn.Dropout(dropout)]
        else:
            layers += [nn.Linear(sizes[j], sizes[j+1]), act()]
    return nn.Sequential(*layers)


class SimpleGCN(nn.Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """
    def __init__(self, in_features, out_features):
        super(SimpleGCN, self).__init__()
        self.in_f = in_features
        self.out_f = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        self.reset_parameters()
        #print('SimpleGCN_in_features:', in_features)
        #print('SimpleGCN_out_features:', out_features)
    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)

    # adj_adjust is D^(-0.5)*(adj+I)*D^(0.5)
    def forward(self, h_0, adj_adjust):
        # what is h_0
        #print('$$$$$$$$$$$$$$$$$$$$$$$$,h_0.shape', h_0.shape)
        #print('$$$$$$$$$$$$$$$$$$$$$$$$,adj_adjust', adj_adjust.shape)
        #print('$$$$$$$$$$$$$$$$$$$$$$$$,self.weight', self.weight.shape)
        support = torch.matmul(h_0, self.weight)
        output = torch.matmul(adj_adjust, support)
        #print('$$$$$$$$$$$$$$$$$$$$$$$$,output.shape', output.shape)
        return output

"""
batch: return (batch_size, one-hot vector encoding for the graph)
one sample: return one-hot vector encoding for the graph
"""
class GCN(nn.Module):
    # self.GCN = GCN(feature_num, ip_node_num=observation_space.shape[0],
    # graph_encoder_hidden=256, num_gnn_layer=2)
    def __init__(self, feature_num, ip_node_num, n_hidden, num_layer):
        super(GCN, self).__init__()
        self.ip_node_num = ip_node_num
        self.feature_num = feature_num
        print('GCN self.ip_node_num', self.ip_node_num)
        print('GCN self.feature_num', feature_num)
        self.gcn_list = []
        for i in range(num_layer):
            if i == 0:
                self.gcn_list.append(SimpleGCN(feature_num, n_hidden))
            elif i == num_layer-1:
                self.gcn_list.append(SimpleGCN(n_hidden, feature_num))
            else:
                # 只有两层，这里没有中间的隐藏层
                self.gcn_list.append(SimpleGCN(n_hidden, n_hidden))
        #print("num of gcn layer:{}".format(len(self.gcn_list)))
        self.gcn_list = nn.ModuleList(self.gcn_list)
        #print('GCN:', self.gcn_list)
    # node_num: n
    # state_node: batch_size*n*feature_num
    # state_adj: batch_size*n*n
    # obs: batch_size*n*(feature_num+n)
    def forward(self, obs):
        # reconstruct state_node and state_adj from flatten_obs
        if (len(obs.size())==3):
            # batch
            
            adj_adjust, h_0 = torch.split(obs,[self.ip_node_num, self.feature_num],dim=2)
            
        else:
            adj_adjust, h_0 = torch.split(obs,[self.ip_node_num, self.feature_num],dim=1)
            
        for gcn in self.gcn_list:
            
            h_0 = F.relu(gcn(h_0, adj_adjust))
        if (len(h_0.size())==3):
            # batch
            bn_emb = torch.flatten(h_0,1)
        else:
            
            bn_emb = torch.flatten(h_0)
        #print('bn_emb',bn_emb.shape)
        return bn_emb

class Actor(nn.Module):

    def _distribution(self, obs):
        raise NotImplementedError

    def _log_prob_from_distribution(self, pi, act):
        raise NotImplementedError

    def forward(self, obs, act=None):
        # Produce action distributions for given observations, and
        # optionally compute the log likelihood of given actions under
        # those distributions.
        pi = self._distribution(obs)
        logp_a = None
        if act is not None:
            logp_a = self._log_prob_from_distribution(pi, act)
        return pi, logp_a


class GCNCategoricalActor(Actor):

    def __init__(self, feature_num, ip_node_num, gcn, hidden_sizes, act_num, activation):
        super().__init__()
        self.ip_node_num = ip_node_num
        self.GCN = gcn
        #self.logits_net = mlp([feature_num*(ip_node_num+self.tbl_info.shape[0])] + list(hidden_sizes) + [act_num], activation)
        self.logits_net = mlp([ip_node_num*ip_fea+(act_num+1+math.ceil(ip_node_num/stage_fea))*stage_fea] + list(hidden_sizes) + [act_num], activation)
        
        #print('MLP:', self.logits_net)
    # logits is the log probability, log_p = ln(p)
    def _distribution(self, obs):
        if (len(obs.size())==3):
            obs_emb = self.GCN(obs[:,:-(obs.shape[1]-self.ip_node_num),:])
            tbl_info = obs[:,-(obs.shape[1]-self.ip_node_num):,-1*stage_fea:]
            # GPU
            obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32).cuda(), 1)),dim=1)
            # cpu
            #obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32), 1)),dim=1)
        else:
            obs_emb = self.GCN(obs[:-(obs.shape[0]-self.ip_node_num)])
            tbl_info = obs[-(obs.shape[0]-self.ip_node_num):,-1*stage_fea:] 
            # GPU                
            obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32).cuda())),dim=0)
            # cpu
            #obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32))),dim=0)
        #print('**************************** obs_emb.shape', obs_emb.shape)
        logits = self.logits_net(obs_emb)
        #print('**************************** logits.shape', logits.shape)
        return Categorical(logits=logits)

    def _get_logits(self, obs):
        if(len(obs.size())==3):
            obs_emb = self.GCN(obs[:,:-(obs.shape[1]-self.ip_node_num),:])
            tbl_info = obs[:,-(obs.shape[1]-self.ip_node_num):,-1*stage_fea:]
            # gpu
            obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32).cuda(), 1)),dim=1)
            # cpu
            #obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32), 1)),dim=1)
        else:
            obs_emb = self.GCN(obs[:-(obs.shape[0]-self.ip_node_num)])
            tbl_info = obs[-(obs.shape[0]-self.ip_node_num):,-1*stage_fea:] 
            # gpu
            obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32).cuda())),dim=0)
            # cpu
            #obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32))),dim=0)
        logits = self.logits_net(obs_emb)
        return logits

    def _log_prob_from_distribution(self, pi, act):
        return pi.log_prob(act)
    
class GCNCritic(nn.Module):

    def __init__(self, feature_num, ip_node_num, gcn, hidden_sizes, activation):
        super().__init__()
        self.GCN = gcn
        self.ip_node_num = ip_node_num
        act_num = self.ip_node_num * 12
        self.v_net = mlp([ip_node_num*ip_fea+(act_num+1+math.ceil(ip_node_num/stage_fea))*stage_fea] + list(hidden_sizes) + [1], activation)
        
    def forward(self, obs):
        if(len(obs.size())==3):
            obs_emb = self.GCN(obs[:,:-(obs.shape[1]-self.ip_node_num),:])
            
            tbl_info = obs[:,-(obs.shape[1]-self.ip_node_num):,-1*stage_fea:]
            #gpu
            obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32).cuda(), 1)),dim=1)
            # cpu
            #obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32), 1)),dim=1)
        else:
            obs_emb = self.GCN(obs[:-(obs.shape[0]-self.ip_node_num)])
            tbl_info = obs[-(obs.shape[0]-self.ip_node_num):,-1*stage_fea:]
            # gpu
            obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32).cuda())),dim=0)
            # cpu
            #obs_emb = torch.cat((obs_emb, torch.flatten(torch.tensor(tbl_info, dtype=torch.float32))),dim=0)
        
        v_mlp = self.v_net(obs_emb)

        return torch.squeeze(v_mlp, -1)


class GCNActorCritic(nn.Module):
    def __init__(self, observation_space, action_space, graph_encoder_hidden=64, num_gnn_layer=2, 
                 hidden_sizes=(64,64), activation=nn.ReLU):
        super().__init__()
        # 将obs分为了两个部分
        
        ip_node_num = action_space.n//12
        #print('ip_node_num', ip_node_num)
        feature_num = observation_space.shape[1] - ip_node_num
        #print('feature_num', feature_num)
        #print('ip_node_num', ip_node_num)
        #print('feature_num', feature_num)
        act_num = action_space.n
        #print('act_num', act_num)
        # GCN: (self, feature_num, ip_node_num, n_hidden, num_layer)
        # self.GCN = GCN(feature_num, ip_node_num=observation_space.shape[0],
        # graph_encoder_hidden=256, num_gnn_layer=2)
        self.GCN = GCN(feature_num, ip_node_num, graph_encoder_hidden, num_gnn_layer)
        self.pi = GCNCategoricalActor(feature_num, ip_node_num, self.GCN, hidden_sizes, act_num, activation)

        # build value function
        self.v = GCNCritic(feature_num, ip_node_num, self.GCN, hidden_sizes, activation)
        #params_num = sum(functools.reduce( lambda a, b: a*b, x.size()) for x in self.parameters())
        #print("# of trainable params:{}".format(params_num))
        #self.nnn = 0
        #ac_path = "results/ac_value.txt"
        #self.ac_fpr = open(ac_path,"w")


    def step(self, obs, mask):
        with torch.no_grad():
            # pi : actor   v: critic
            # VPG 319行左右访问ac.step
            # actor正向傳播
            #obs = obs[:-1]
            # little trick, the mask is zero while it should update the nn, zero mask may
            # trigger no ant entry can be select in logp_a
            if(sum(mask) ==0):
                mask[0] = 1
            pi = self.pi._distribution(obs)
            
            pi_logits = self.pi._get_logits(obs)
            #print('pi_logits~~~~~~~~~~~~~~~~~~', pi_logits.shape)
            #self.nnn = self.nnn + 1
            #if(self.nnn % 4096 == 0):
                #with open('v1.txt', 'a') as file:
                    #file.write(str(pi_logits))
                    #file.write("\n")
            # shut donw mask
            pi_logits_delta = torch.zeros(mask.size()).to(mask.device)
            
            pi_logits_delta[mask == 0] = float("-Inf")
            pi_logits += pi_logits_delta
            pi_mask = Categorical(logits=pi_logits)
            
            
            #ran_num = random.randint(1, 10)
            #if(ran_num>=9):
                #a = pi_mask.sample()
            
            #else:
                # dqn
                #a = torch.max(pi_logits, 0)[1]
            
            # vpg
            a = pi_mask.sample()
            
            
            logp_a = self.pi._log_prob_from_distribution(pi, a)
            
            v = self.v(obs)
                        
        return a.cpu().numpy(), v.cpu().numpy(), logp_a.cpu().numpy()
    