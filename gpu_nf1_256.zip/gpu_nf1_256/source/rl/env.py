# -*- coding: utf-8 -*-
from topology import topology
#from rl import Hyperparameters
import gym
from copy import deepcopy
import numpy as np
import pdb, os, time, json
import math, sys


### Hyperparameters: ###
Max_action = math.pow(2,9)
Steps_per_epoch = math.pow(2,10)
max_tbl_num = 24


class psfcEnv(gym.Env):
    def __init__(self, topo:topology, max_action=Max_action, steps_per_epoch=Steps_per_epoch,\
                graph_encoder='HGNN'):
        self.max_action = max_action
        self.steps_per_epoch = steps_per_epoch
        self.topo = topo
        self.action_cnt = 0
        self.graph_encoder = graph_encoder
        self.norm_param = 0.01
        self.cost_dict = {'s':0, 'sw':0, 'link':0}
        # related to utils
        #self.topo_preprocess()
        #self.original_topo = deepcopy(topo)
        self.mask = None
        # 下划线：丢弃第二个返回值mask
        obs, _ = self.get_observation()
        
        # 保存table和部署stage的位置
        self.action_list = []
        
        self.observation_space = gym.Space(shape=list(obs.shape))
        self.action_space = gym.spaces.Discrete(self.topo.topo_adj_matrix.shape[0]*12)
        # 是gym里的内置变量，也是AC网络的输入
        #******************************************************************#
        ##*************   1、需要补充完整   (Done)   *******************************#
        #self.observation_space = gym.Space(shape=list(obs.shape))
        #print("obv_space size: {}".format(self.observation_space.shape))

        #self.action_space = gym.spaces.Discrete(self.topo.topo_adj_matrix.shape[0]*12)
        #print("act_space size: {}".format(self.action_space.n))
        #******************************************************************#
        
        # 计算总的reward   (变量名未改)
        self.cum_rwd = 0
        # 计算有多少已保存的方案 （变量名未改)
        self.complete_cnt = 0
        # 保存一次方案的cum_rwd   (变量名未改)
        self.max_rwd = 0
        # 跟opt相关变量，opt是新or旧的保存的方案
        self.opt_target = None
        self.cost = 0
        #self.optm_topo = self.topo
        #self.optm_ob = None
        self.opt_tbl_place = {}
        self.optm_epoch_idx = 0
        
        self.epoch_idx = 0
        self.start_sec_ts = int(time.time())
        
        # 地址相关
        action_path = "results/actions.txt"
        self.action_fpr = open(action_path,"w")
        stages_path = "results/stages.txt"
        self.stages_fpr = open(stages_path,"w")

        
        # trajectory相关
        self.action_cnt_cum = 0 # to record the epoch num
        self.traj_set = set()
        self.main_epoch_traj_stats_list= []
        rwd_path = "results/rwd.txt"
        traj_path = "results/traj.txt"
        self.traj_fpr = open(traj_path,"w")
        self.rwd_fpr = open(rwd_path,"w")
        
        self.main_epoch_traj_num = 0
        self.main_epoch_traj_num_visited = 0
        self.main_epoch_cache_hit_num = 0
        
        self.tra_num = 0
        # cache相关 是否需要？？
        # each state is represented as a frozenset((l3_link_idx1, delta_bw), (l3_link_idx2, delta_bw),...)
        '''
        self.state_map_fp_cache = {}
        self.cache_max_entry = 1e6
        self.cache_path = "results/{}/cache".format(log_dir)
        if not os.path.exists(self.cache_path):
            os.makedirs(self.cache_path)
        '''
        self.test_n = 0
    # gym specific
    def step(self, action):
        # 输入是action，做了ac得到的动作后，返回相关值
        # 返回值是这四个
        # obs传给ac；
        obs, reward, done, info, mask, mask_flag = None, None, False, None, None, None
        # flag
        # 
        action_exer_flag = False
        sat_flag = False
        
        #******************************************************************#
        ##*************   2、动作如何设计？  (Done)    *******************************#
        # action为整数，代表在哪一个stage部署table
        action_int = int(action)
        #******************************************************************#
        
        # action
        #******************************************************************#
        ##*************   3、执行动作action的函数 (Done)  *******************************#
        # todo:  SFC_tbl如何传入？
        
        big_tbl_flag, res_flag, cost, sat_flag, sub_flag, dep_flag, btl, cost_dict = self.topo.action_exection_of_table_placement(action_int)
        #******************************************************************#
        action_exer_flag = big_tbl_flag or res_flag or sub_flag or dep_flag
        if(cost_dict != {'s':0, 'sw':0, 'link':0}):
            self.cost_dict['s'] = self.cost_dict['s'] + cost_dict['s']
            self.cost_dict['sw'] = self.cost_dict['sw'] + cost_dict['sw']
            self.cost_dict['link'] = self.cost_dict['link'] + cost_dict['link']
        
        ###### mask ##################
        '''
        if(self.mask != None):
            if(self.mask[action] == 0):
                action_exer_flag = True
        '''
        ###### mask ##################
        
        # action的信息录入
        #******************************************************************#
        ##*************   4、action的信息录入   (Done)   *******************************#
        ##  ----> (SFC_ID, tbl_name, stage)
        #self.action_list.append(('SFC-'+str(self.topo.sfc.sfc_exer_num),\
        #                         self.topo.sfc.return_tbl_name(), action_int))
        #******************************************************************#
        self.action_cnt += 1
        self.action_cnt_cum += 1
        
        # 观察obs和mask
        #btl is flag if repeatly deploy the same big table
        if(sat_flag == False):
            if(btl == True):
                obs, mask = self.get_observation(action_int, btl=True)
                #mask_gamma = 1
            elif(btl == False):
                obs, mask = self.get_observation(action_int)
                
                    
                #mask_gamma = mask.count(1)/len(mask)*5
            # 没有action可用时返回错误
            if sum(mask)==0:
                action_exer_flag = True
                mask_flag = True
                cost = 1000
        elif(sat_flag == True):
            obs = self.topo.get_observation(action_int, sat=True)
            mask = [0] * self.topo.node_fea_matrix.shape[0]
            #mask_gamma = 1
        
        ############### mask ###########
        '''
        self.mask = mask
        mask = [1] * self.topo.node_fea_matrix.shape[0]
        '''
        ############### mask ###########
        # 由cost判断 是否违反
        #进一步判断是否满足部署条件
        #******************************************************************#
        ##*************   5、判断是否满足部署条件      *******************************#
        if(action_exer_flag == False):
            # check the spof constraints further
            # sat_flag, cache_hit_flag, self.state_map_fp_cache = self.topo.check_spof(l3_link_idx, delta_bw_act, self.state_map_fp_cache, self.cache_max_entry, self.checker_mode)
            reward = cost * -1 * self.norm_param
            #reward = round(cost * -1 , 10)
            self.cost = cost + self.cost
        else:
            reward = 0
        #if(mask_flag == True or self.action_cnt_cum%self.steps_per_epoch == 0):
        #    if(sat_flag != True):
        #        self.cost = self.cost + 1000
        #******************************************************************#
        #******************************************************************#
        ##*************   6、flag需要重新设计！！*******************************#
        #if cache_hit_flag:
        #    self.main_epoch_cache_hit_num += 1
            
        # 判断终止条件
        
        if action_exer_flag == True or self.action_cnt >= self.max_action or sat_flag == True:
            done = True
           
        # done 是当所有SFC部署完毕返回True
        if(done == True):
            if(sat_flag == True):
                reward = reward + 1000
            else:
                reward = reward - 1
        
        if(self.action_cnt_cum%self.steps_per_epoch == 0):
            reward = reward - 1

        self.cum_rwd = self.cum_rwd + reward
        
        if (sat_flag == True):
            self.save_if_best()
            
        
        if done or (self.action_cnt_cum%self.steps_per_epoch == 0):
            # save trajectory and plan results
            self.save_trajectory(action_exer_flag, self.cost, self.cum_rwd, \
                                 mask_flag, big_tbl_flag, res_flag, sub_flag, dep_flag, mask)
        info = {"log_ptr": self.traj_fpr, "extra_rwd":None}

        #if(self.tra_num %50 == 0):
            #print('the num of tra is:', self.tra_num)
        #if(self.action_cnt_cum%500 == 0):
            #print('the num of action_cnt_cum is:', self.action_cnt_cum)
        if(mask == None):
            print('mask is none!!!!!!!!!')
            mask = [1] * self.topo.node_fea_matrix.shape[0]
        return obs, mask, reward, done, info
        
    # gym specific
    def reset(self):
        self.action_cnt = 0
        self.cum_rwd = 0
        self.cost = 0
        self.action_list = []
        self.topo.reset()        
        self.epoch_idx += 1
        self.cost_dict = {'s':0, 'sw':0, 'link':0}
        sys.stdout.flush()
        return self.get_observation()
    
    def get_observation(self, action=None, btl=False):
        #******************************************************************#
        ##*************   8、HGNN的设计   (Done)  *******************************#
        #******************************************************************#
        
        
        if(action!=None and btl == False):
            mask = self.topo.get_action_mask(action)
        elif(action!=None and btl == True):
            mask = self.topo.get_action_mask(action, btl=True)
        else:
            mask = self.topo.get_action_mask(action, type='init')
        obs = self.topo.get_observation(mask)
        ############### mask ###########
        
        #obs = self.topo.get_observation(mask=mask)
        
        ############### mask ###########
        return obs, mask
        
    # 这里不需要获取topo，因为不会变化，而是需要获取fea矩阵    
    def terminate(self):
        # 关闭存储tra的文件
        #self.action_fpr.write("epoch_cnt:{}, ip_node_num:{}\n".format(self.epoch_idx, self.max_ip_node))
        self.action_fpr.write("total_time(sec):{}\n".format(int(time.time())-self.start_sec_ts))
        self.action_fpr.close()
        
    def save_trajectory(self, flag, cost, reward, mask_flag, big_tbl_flag, res_flag, sub_flag, dep_flag,mask):
        self.tra_num  = self.tra_num + 1
        main_epoch_idx = int((self.action_cnt_cum-1)/self.steps_per_epoch)
        if(self.tra_num % 1 == 0):
            
            self.traj_fpr.write("main epoch idx:{}, act_flag:{}, cost:{}, rwd:{}, mask:{}, sfcid:{}, tbl:{}\n".\
            format(main_epoch_idx, flag, int(cost), int(reward), mask_flag, self.topo.sfc.sfc_exer_num, self.topo.sfc.seq_num))

            
            for key in self.topo.tbl_rel_record.keys():
                self.traj_fpr.write("key:{}, v:{}\n".format(key,self.topo.tbl_rel_record[key]))
                try:
                    self.traj_fpr.write("key:{}, v:{}\n".format(key,self.topo.link_rel_record[key]))
                except:
                    None
            self.rwd_fpr.write("idx-{}: {}\n".format(main_epoch_idx ,int(reward)))
            #print(self.topo.tbl_rel_record)
            if(len(self.topo.tbl_rel_record) ==1):
                stage_occu = []
                for key in self.topo.tbl_rel_record.keys():  
                    for key2 in self.topo.tbl_rel_record[key].keys():
                        stage_occu.extend(self.topo.tbl_rel_record[key][key2][::2])    
                # output stage number:
                stage_occu = list(set(stage_occu))
                self.stages_fpr.write("idx:{}, stage number:{}\n".format(main_epoch_idx, len(stage_occu)))
                if(len(stage_occu)<=23):
                    for key in self.topo.tbl_rel_record.keys():
                        self.stages_fpr.write("key:{}, v:{}\n".format(key,self.topo.tbl_rel_record[key]))
                        try:
                            self.stages_fpr.write("key:{}, v:{}\n".format(key,self.topo.link_rel_record[key]))
                        except:
                            None
        self.traj_fpr.flush()
        self.rwd_fpr.flush()
        self.stages_fpr.flush()
        
        
    
    def save_if_best(self):
        self.complete_cnt += 1
        if self.opt_target == None or self.opt_target > self.cost:
        #if self.max_rwd < self.cum_rwd:
            self.max_rwd = self.cum_rwd
            self.opt_target = self.cost
            # topo placement result
            self.opt_tbl_place = self.topo.tbl_place
            # action list
            self.optm_epoch_idx = self.epoch_idx
            stage_occu = []
            node_occu = []
            main_epoch_idx = int((self.action_cnt_cum-1)/self.steps_per_epoch)    
            self.action_fpr.write("main epoch idx:{},  cost:{}, rwd:{}".\
            format(main_epoch_idx, self.opt_target, self.max_rwd))
            
            self.action_fpr.write("  detail cost:{}\n".\
            format(self.cost_dict))
            for key in self.topo.tbl_rel_record.keys():
                self.action_fpr.write("key:{}, v:{}\n".format(key,self.topo.tbl_rel_record[key]))
                self.action_fpr.write("key:{}, v:{}\n".format(key,self.topo.link_rel_record[key]))
                for key2 in self.topo.tbl_rel_record[key].keys():
                    stage_occu.extend(self.topo.tbl_rel_record[key][key2][::2])
                    
                for key2 in self.topo.link_rel_record[key].keys():
                    if(self.topo.link_rel_record[key][key2] != 'SameNode*'):
                        node_occu.extend(self.topo.link_rel_record[key][key2])
            # output stage number:
            stage_occu = list(set(stage_occu))
            node_occu = list(set(node_occu))
            
            self.action_fpr.write("stage number:{}->{}, node_number:{}\n".format(len(stage_occu), stage_occu,len(node_occu)))
            stage_info_detail = {}
            for sfcid, v_item in self.topo.tbl_rel_record.items():
                for tbl, s_info in v_item.items():
                    tbl_name = self.topo.sfc.sfc_seq_name_list[sfcid][tbl]
                    for s in s_info[0::2]:
                        try:
                            if(tbl_name not in stage_info_detail[s]):
                                stage_info_detail[s].append(tbl_name)
                            else:
                                stage_info_detail[s].append(str(tbl_name)+'_id'+str(sfcid))
                        except:
                            stage_info_detail[s] = []
                            stage_info_detail[s].append(tbl_name)
            sfc_id_list = list(stage_info_detail.keys())
            sfc_id_list.sort()
            for i in sfc_id_list:
                self.action_fpr.write('{}:{}\n'.format(i,stage_info_detail[i]))
            self.action_fpr.write('node:{}\n'.format(self.topo.sfc.subnode_for_cost))

            self.action_fpr.flush()

        
        
    
    
    
    
    
    
    
    
    
    
    
