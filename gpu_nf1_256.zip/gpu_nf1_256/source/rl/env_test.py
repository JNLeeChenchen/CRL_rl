# -*- coding: utf-8 -*-
from source.topology import topology, SFC, network, pipeline
from ac import GCNActorCritic
import numpy as np
import torch
import test
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 23 15:04:56 2022

@author: 82633
"""

from source.topology import *
import networkx as nx
import numpy as np

np.set_printoptions(threshold=np.inf)

def print_var(topo):
    topo.print_var()
    #topo.sub.print_var()
    #topo.sfc.print_var()
    
def add_table(topo, table, table_info, seq_num=0):
    try:
        topo.tbl_place[table].extend(table_info)
    except:
        topo.tbl_place[table] = []
        topo.tbl_place[table].extend(table_info)
    if(seq_num != 0):
        topo.sfc.seq_num = seq_num

def init_topo_SFC(topo_name, topo_file_path, SFC_num, adjust_factor_in=None):
    
    '''
    topo_name_map_file_path = {}    
    file_path = topo_name_map_file_path[topo_name]
    '''
    
    topo = Topology(SFC_num)
    topo.topo_preprocess(topo_file_path)

    '''
    topo.sfc.seq_num = 0
    print(topo.action_exection_of_table_placement(1))
    mask = topo.get_action_mask(1)
    print('mask', mask)
    print('topo.mask_plu_dict', topo.mask_plu_dict)
    
    topo.sfc.seq_num = 7
    print(topo.action_exection_of_table_placement(3))
    mask = topo.get_action_mask(3)
    print('mask', mask)
    
    
    topo.sfc.seq_num = 8
    print(topo.action_exection_of_table_placement(37))
    mask = topo.get_action_mask(37)
    print('mask', mask)
    
    topo.sfc.seq_num = 9
    print(topo.action_exection_of_table_placement(35))
    mask = topo.get_action_mask(35)
    print('mask', mask)
    
    #print(topo.ob_sfc_info)
    topo.sfc.seq_num = 12
    act = 15
    reward = topo.action_exection_of_table_placement(act)[2]
    print('reward:,', reward)
    print(topo.sfc.seq_num)
    mask = topo.get_action_mask(act)
    print(mask)
    print('mask reward:,', reward*(mask.count(1)/len(mask)))
    '''
    return topo



topo_name = 'random'
SFC_num =1
topo_file_path = 'node4.csv'
topo = init_topo_SFC(topo_name, topo_file_path, SFC_num)



print('*****************************')
print('**********input of GNN*******')
obs = topo.get_observation()
#print(obs)

print('*****************************')



