# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, "../spinningup/")
from spinup import vpg_pytorch

import pdb, time, torch

from rl.env import psfcEnv
from rl.ac import GCNActorCritic

class RL(object):
    def __init__(self, topo, graph_encoder='GCN', num_gnn_layer=2,\
                 hidden_sizes=(256, 256), \
            epoch_num=300, max_action=1024, steps_per_epoch=2048, model_path=None):
        
        self.topo = topo
        self.graph_encoder = graph_encoder
        self.num_gnn_layer = num_gnn_layer
        self.hidden_sizes = hidden_sizes
        
        self.max_action = max_action
        self.steps_per_epoch = steps_per_epoch
        self.epoch_num = epoch_num
        self.model_path = model_path


        
        log_dir_name_list = [int(time.time()), self.graph_encoder, \
             self.steps_per_epoch]
        self.log_dir = '_'.join([str(i) for i in log_dir_name_list])

    def get_env(self):
        self.env = psfcEnv(self.topo, graph_encoder=self.graph_encoder, \
            max_action=self.max_action, steps_per_epoch=self.steps_per_epoch)
        return self.env

    def run_training(self):
        logger_kwargs = dict(output_dir="results/{}".format(self.log_dir), exp_name="test")
        ac_kwargs = dict(graph_encoder_hidden=128,hidden_sizes=self.hidden_sizes, num_gnn_layer=self.num_gnn_layer)

        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        ac = GCNActorCritic

        vpg_pytorch(self.get_env, enable_mpi=False, non_blocking=False, gamma=0.99, actor_critic=ac,\
            max_ep_len=self.max_action, seed=8, lam=0.97, device=device, \
            model_path=self.model_path, \
            ac_kwargs=ac_kwargs,epochs=self.epoch_num,steps_per_epoch=self.steps_per_epoch,logger_kwargs=logger_kwargs)

        self.env.terminate()