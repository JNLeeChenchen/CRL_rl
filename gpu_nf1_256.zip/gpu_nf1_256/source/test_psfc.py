# -*- coding: utf-8 -*-

from topology.topology import Topology
from rl.rl_main import RL

#from spinup import vpg_pytorch
def init_topo_from_file(topo_file_path):
    sfc_num = 1
    topo = Topology(sfc_num)
    topo.topo_preprocess(topo_file_path)
    return topo

#topo_file_path = 'abovenet.csv'
topo_file_path = 'node4.csv'
rl_solve = RL(topo=init_topo_from_file(topo_file_path),\
              num_gnn_layer=2)
rl_solve.run_training()


