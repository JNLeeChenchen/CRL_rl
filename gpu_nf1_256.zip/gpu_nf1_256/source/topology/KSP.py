import numpy as np
import networkx as nx
import copy as cp

def KSP(graph, source, destination, kpath):
    # input: source des
    # graph = nx.DiGraph()   k number of backup path
    # return k-shortest path LIST!!!!
    G = graph
    source = source
    des = destination
    kpath = kpath
    '''
    graph.add_nodes_from([1,2,3,4,5,6,7])
    graph.add_weighted_edges_from(
        [(1, 2, 1), (2, 3, 1), (3, 4, 1), (4, 7, 1), (2, 5, 6), (5, 3, 5), (5, 6, 4), (3, 6, 2), (6, 4, 1)])
    nx.draw(graph, with_labels=True, nodelist=graph.nodes())
    source = 1
    slink = 7
    kpath = 5
    '''
    A = []
    B = []
    A.append(tuple(nx.dijkstra_path(graph,source,slink)))
    for k in range(1, kpath):
        for i in range(0, len(A[k - 1])-1):
            g = cp.deepcopy(graph)
            spurnode = A[k - 1][i]
            rootpath = A[k - 1][0:i]
            for p in A:
                if rootpath == p[0:i]:
                    if g.has_edge(p[i], p[i + 1]):
                        g.remove_edge(p[i], p[i + 1])
            for rootpathnode in rootpath:
                if g.has_node(rootpathnode):
                    g.remove_node(rootpathnode)
            try:

                spurpath = nx.dijkstra_path(g, spurnode, slink)
                totalpath = list(rootpath) + spurpath

                B.append(tuple(totalpath))
            except nx.NetworkXNoPath:
                continue
        if not B:
            break
        g=cp.deepcopy(graph)
        for i in range(len(B) - 1):
            for j in range(len(B) - 1):
                costi = 0
                for nodei in range(len(B[i]) - 1):
                    costi = costi + g.get_edge_data(B[i][nodei], B[i][nodei + 1])["weight"]
                costj = 0
                for nodei in range(len(B[j]) - 1):
                    costj = costj + g.get_edge_data(B[j][nodei], B[j][nodei + 1])["weight"]
                if costi < costj:
                    t = B[i]
                    B[i] = B[j]
                    B[j] = t
        A.append(B[0])
        #print(B)
        B.remove(B[0])
    return A

'''
graph = nx.DiGraph()
graph.add_nodes_from([1,2,3,4,5,6,7])
graph.add_weighted_edges_from(
    [(1, 2, 1), (2, 3, 1), (3, 4, 1), (4, 7, 1), (2, 5, 6), (5, 3, 5), (5, 6, 4), (3, 6, 2), (6, 4, 1)])
nx.draw(graph, with_labels=True, nodelist=graph.nodes())
source = 1
slink = 7
kpath = 3
A = KSP(graph, 1, 7, kpath)
print('A:', A)
'''