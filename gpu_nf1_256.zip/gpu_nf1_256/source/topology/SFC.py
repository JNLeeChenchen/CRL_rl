import numpy as np
import copy
from topology.sfc_material import *
from topology.netfun_rl import *
from topology.greedy_rl import *

'''
7. spread_init(p4)-> UDP_flood_init(u4)->flow_size_init(F4)->sflow_init(w3)->ACL_init(a4)=19
2. spread_init(p4) -> flow_size_init(F4)-> CM_init(c5) -> qos_init(q3)=16
3. ES_init(e5) -> HH2_init(H4) -> flowlet_init(f6) ->ecmp_init(E5) -> HH1_init(h3)->spread_init(p4)=27
6.ES_init(e5)->CM_init(c5)=12
1. ACL_init(a4)->CM_init(c5)->SYN_HH_init(s4)=13
'''

class SFC:
    def __init__(self, SFC_number):
        self.SFC_number = SFC_number
        self.sfc_exer_num = 0
        #self.sfc_list = SFC_list
        # 保存每一个big tbl内部的link，tbl_link_dict={tbl:{s1->d1:path1, s2->d2:path2}， tbl:[{}]}
        #self.tbl_link_dict = self.tbl_link_init()
        self.init_sfc_info()
        self.seq_num = 0
        self.node_memory_total = node_memory_total
        # 保存tbl放置的名字，出现重复时不另外消耗资源
        self.save_per_sfc_tbl_place = {}
        self.subnode_for_cost = []
        
        ## mask+ ##
        self.init_sfc_remind_cache()
        self.sfc_seq_name_list = SFC_seq_name_list
        self.init_sfc_dep_matrix_cache_sfcid_tbl()
        
        
    #  todo   
    #  每条新的SFC进入时，需要更新sub_network中link的occu值，重置为1
    
    def reset(self):
        self.sfc_exer_num = 0
        self.seq_num = 0
        self.save_per_sfc_tbl_place = {}
        # link
        #self.link_ksp_dict = copy.deepcopy(link_ksp_dict_list[self.sfc_exer_num])
        #self.sfc_input_info = SFC_input_info_list[self.sfc_exer_num]
        # 存放SFC输入的序列topo_seq
        #self.sfc_input_seq = self.sfc_input_seq_init()
        #self.unreach_dict = self.create_unreach_dict()
        self.subnode_for_cost = []
        self.init_sfc_info()
    
    def init_sfc_info(self):
        self.sfc_bw = SFC_bw_list[self.sfc_exer_num]
        
        # 由输入序列得到的dep矩阵
        self.sfc_dep_matrix = np.array(SFC_dep_matrix_list[self.sfc_exer_num])
        ## mask+ ##
        self.sfc_dep_matrix_cache = SFC_dep_mask_cache_list[self.sfc_exer_num]

        #self.sfc_dep_matrix_cache_plus = SFC_dep_mask_cache_list[self.sfc_exer_num+1]
        self.sfc_dep_matrix_cache_plus = []
        self.sfc_input_info = SFC_input_info_list[self.sfc_exer_num]
        
        #self.sfc_input_info_plus = SFC_input_info_list[self.sfc_exer_num+1]
        self.sfc_input_info_plus = []
        self.sfc_input_seq = self.sfc_input_seq_init()
        self.sfc_input_seq_plus = self.sfc_input_seq_init(flag=1)

        self.sfc_logit_pre_dict = sfc_logit_pre_dict_list[self.sfc_exer_num]
        self.sfc_logit_dict = sfc_logit_dict_list[self.sfc_exer_num]
        # link_ksp_dict： 保存virtual link的信息
        self.link_ksp_dict = copy.deepcopy(link_ksp_dict_list[self.sfc_exer_num])
        self.sfc_tbl2path = SFC_tbl2path_list[self.sfc_exer_num]
        self.sfc_path_len = SFC_path_len_list[self.sfc_exer_num]
        #self.sub_node_in_vlink = self.create_sub_node_in_vlink()
        # 不可达字典, {path:[s_n1, sub_node2,...], path2:[]...}
        self.unreach_dict = self.create_unreach_dict()
        # predicted dep length
        #self.tbl_max_stage = self.init_tbl_max_stage()
    
    def init_sfc_dep_matrix_cache_sfcid_tbl(self):
        sfcid_tbl = {}
        tbl_size = [len(SFC_seq_name_list[0])]
        for i in range(len(SFC_dep_mask_cache_list)):
            for k in SFC_dep_mask_cache_list[i].keys():
                if(k!=0):
                # non-0
                    try:
                        sfcid_tbl[i].append(k-1)
                    except:
                        sfcid_tbl[i] = []
                        sfcid_tbl[i].append(k-1)
                else:
                # 0
                    if(i == 0):
                        continue
                    else:
                        try:
                            sfcid_tbl[i-1].append(tbl_size[i-1])
                        except:
                            sfcid_tbl[i] = []
                            sfcid_tbl[i-1].append(tbl_size[i-1])
        self.sfc_dep_matrix_cache_sfcid_tbl = sfcid_tbl

    ## mask+ ##
    def init_sfc_remind_cache(self):
        sfc_remind_cache = {}
        for i in range(self.sfc_dep_matrix.shape[0]):
            j = i+1
            sfc_remind_cache[i] = []
            while(j<self.sfc_dep_matrix.shape[0]):
                if(self.sfc_dep_matrix[i][j] == 1):
                    sfc_remind_cache[i].append(j)
                j = j + 1
        self.sfc_remind_cache = sfc_remind_cache
    
    
    def init_tbl_max_stage(self):
        tbl_max_stage = []
        for i in range(self.sfc_dep_matrix.shape[0]):
            j = i
            n = 0
            while(j<self.sfc_dep_matrix.shape[1]):
                n = n + self.sfc_dep_matrix[i][j]
                j = j + 1
            tbl_max_stage.append(n)
        
        
        i = len(tbl_max_stage)-1
        max_value = tbl_max_stage[i]
        
        while(i>0):
            
            i = i - 1
            
            if(tbl_max_stage[i] < max_value):
                tbl_max_stage[i] = max_value
            else:
                max_value = tbl_max_stage[i]
                
        return tbl_max_stage
        
    def create_unreach_dict(self):
        res = {}
        for i in range(self.sfc_path_len):
            res[i] = []
        return res
    def sfc_input_seq_init(self, flag=0):
        sfc_input_seq = {}
        n = 0
        if(flag == 0):
            sfc_input_info = self.sfc_input_info
        else:
            sfc_input_info = self.sfc_input_info_plus
        for item in sfc_input_info:
            # [None, sram, tcam, type]
            sfc_input_seq[n] = [item[0],  item[2], item[3], item[1], item[4], item[5]]
            n = n + 1
        return sfc_input_seq
        
    def return_tbl_name(self):
        name = self.sfc_input_info[self.seq_num][0]
        return name
         
         
#    def tbl_link_init(self):
#        tbl_link_dict = self.sfc_logit_dict
#        keys = tbl_link_dict.keys()
#        for key in keys:
#            tbl_link_dict[key] = {}
#        return tbl_link_dict
        
    def get_link_name(self, node1, node2):
        try:
            self.link_ksp_dict[str(node1)+'-'+str(node2)]
            return str(node1)+'-'+str(node2)
        except:
            try:
                self.link_ksp_dict[str(node2)+'-'+str(node1)]
                return str(node2)+'-'+str(node1)
            except:
                print('get link name failed !!!!')
    def get_SFC_input_info_list(self):
        return SFC_input_info_list

    def print_var(self):
        print('##### SFC情况 #########')
        print('##### 存放SFC输入的序列 #########')
        print('self.sfc_input_seq:,', self.sfc_input_seq)
        print('##### dep矩阵 #########')
        print('self.sfc_dep_matrix:,', self.sfc_dep_matrix)
        print('##### 当前sub link分配信息 #########')
        print('self.link_ksp_dict:,', self.link_ksp_dict)
        print('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')
        print('')
        
        
        
        