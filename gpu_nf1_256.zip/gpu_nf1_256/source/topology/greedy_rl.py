import numpy as np
import copy
import time
from topology.netfun_rl import *

t3 = time.time()
def dep_M(chain):
    seq_topo_temp = chain.topologic_sequence()
    
    after_nodes_cache2 = {}
    for node in seq_topo_temp:
        after_nodes_cache2[node] = chain.search_all_after_node(node)
    
    # pop start end
    #seq_topo_temp.pop(0)
    #seq_topo_temp.pop(-1)
    dep_m_dict = {}
    # 两种添加 （1）条件 （2）tbl冲突
    for tbl in seq_topo_temp:
        after_nodes_cache = copy.deepcopy(after_nodes_cache2)
        # list记录该tbl所有有dep的tbl
        dep_m_dict[tbl] = []
        next_node_list = [tbl]
        next_node_list = chain.search_after_node(next_node_list[0])
        if(len(next_node_list)>=1):
            # 0、 初始dep
            
            
            # 1、 域冲突
            tbl_list = after_nodes_cache[tbl]
            try:
                tbl_list.remove('end')
            except:
                None
            
            for tbl_l in tbl_list:
                action_list = chain.vertList[tbl].action    
                if(action_list == []):
                    continue
                else:
                    action_list = set(action_list)
                    action_list_2_m = set(chain.vertList[tbl_l].match)
                    action_list_2_a = set(chain.vertList[tbl_l].action)
                    if( len(action_list&action_list_2_m) >0 or len(action_list&action_list_2_a) > 0):
                        dep_m_dict[tbl].append(tbl_l)
            
            # 2、条件依赖
            if(len(next_node_list)>1):
                
                dep_nodes = []
                # 找到所有后继节点的共同通向的节点：                
                n = 0
                temp1 = set(after_nodes_cache[next_node_list[n]])
                while(n<len(next_node_list)-1):
                    n = n + 1
                    temp1 = temp1 & set(after_nodes_cache[next_node_list[n]])
                after_common_nodes = list(temp1)
                if (after_common_nodes != []):
                    # 判断这些节点是否可以跟所有的互通，如果无法互通则删除
                    del_list = []
                    for node in after_common_nodes:
                        for i in range(len(next_node_list)):
                            for node2 in after_nodes_cache[next_node_list[i]]:
                                if(node not in after_nodes_cache[node2]  and node2 not in after_nodes_cache[node]):
                                    if(node != node2):
                                        del_list.append(node)   
                    # 计算互通点中
                    del_list = list(set(del_list))
                    
                    for node in del_list:
                        after_common_nodes.remove(node)
                    
                    
                    # 找出这些互通点中after_common_nodes，最前的一个节点
                    if(after_common_nodes !=['end'] or after_common_nodes != []):
                        
                        temp_n = after_common_nodes[0]
                        n = 0
                        if(len(after_common_nodes)>1):
                            while(n<len(after_common_nodes)-1):
                                n = n + 1
                                # 比较temp_n和after_common_nodes[n]谁在前面
                                if(temp_n in after_nodes_cache[after_common_nodes[n]]):
                                    temp_n = after_common_nodes[n]
                    
                    after_common_nodes = after_nodes_cache[temp_n]
                    after_common_nodes.append(temp_n)
                    
                    dep_nodes = list(set(tbl_list) - set(after_common_nodes))
                    #dep_nodes.append(temp_n)
                    #dep_nodes.extend(next_node_list)
                    for node in dep_nodes:
                        dep_m_dict[tbl].append(node)     
                    if('end' in dep_m_dict[tbl]):
                        dep_m_dict[tbl].remove('end')
                    if(tbl in dep_m_dict[tbl]):
                        dep_m_dict[tbl].remove(tbl)
    #print(dep_m_dict)     
    #print('--')
    #print(list(dep_m_dict.keys()))

    # dict转为矩阵
    dep_m = np.full([len(dep_m_dict), len(dep_m_dict)],0)
    tbl_dict = {}
    num = 0
    for key in dep_m_dict.keys():
        tbl_dict[key] = num
        num = num + 1
    num = 0
    #print('tbl_dict,', tbl_dict)
    for key in dep_m_dict.keys():
        for tbl in dep_m_dict[key]:
            try:
                dep_m[num][tbl_dict[tbl]] = 1
                #dep_m[tbl_dict[tbl]][num] = 1
            except:
                None
        num = num + 1
    place_res = {}
    n = dep_m.shape[0]-1
    while(n>=0):
        if(sum(dep_m[n]) == 0):
            n = n - 1
            continue
        else:
            place_res[n] = []
            for i in range(len(dep_m[n])):
                if(dep_m[n][i] == 1):
                    try:
                        place_res[n].extend(place_res[i])
                        place_res[n].append(i)
                    except:
                        place_res[n].append(i)
            place_res[n] = list(set(place_res[n]))
        n = n - 1
    
    # 加入原本cfg中定义的dep
    origi_dep = []
    for node_dep in chain:
        dep_list = chain.find_dep_node(node_dep.id)
        if(dep_list!=[]):
            for node_next in dep_list:
                origi_dep.append((node_dep.id,node_next))
    
    for key,value in origi_dep:
        dep_m[tbl_dict[key]][tbl_dict[value]] = 1
        dep_m[tbl_dict[value]][tbl_dict[key]] = 1
    
    return dep_m,tbl_dict
'''
M, tbl_dict = dep_M(SFC_result)
M_list = []
tbl_dict_list = []
SFC_LIST = []
'''

def node_dep_func(dep_list, node_list, seq_list):
    # 计算每个node的前置dep的端点是什么
    # node->i  node_dep_dict[i] = [node]
    node_dep_dict = {}
    for nf in node_list:
        for n, n_id in nf.items():
            node_dep_dict[n] = []
            for i in range(0, n_id):
                if(dep_list[node_list.index(nf)][i][n_id] == 1):
                    # i 有dep
                    node_dep_dict[n].append(list(nf.keys())[i])
    
    #for i in node_dep_dict.keys():
    #    print(i,'->', node_dep_dict[i])
    # 1。将node分类
    seq_list_sw = []
    seq_list_con = []
    for node in seq_list:
        if(node_memory_total[node.split('#')[0]]['bi'] == 0):
            seq_list_sw.append(node)
        else:
            seq_list_con.append(node)
    seq  = seq_list_sw + seq_list_con
    
    # 保证不会有node在部署前，其前一个有dep 的node还没有部署
    # todo
    for node, node_dep_list in node_dep_dict.items():
        for node_dep in node_dep_list:
            if(seq.index(node)<seq.index(node_dep)):
                # 移动位置node_dep到node的前面
                #print('位置错位，调整',node, '->', node_dep)
                seq.remove(node_dep)
                seq.insert(seq.index(node),node_dep)
    
    return node_dep_dict, seq

def greedy_decomposition_cost(seq_list, dep_list, node_list, sub_resouce, node_dep_dict):
    # greedy_decomposition(g, seq, M, tbl_dict)
    # M 是CFG的dep M， tbl_dict是node:index，对应dep_m的标号
    # seq 是CFG的node
     
    # 2. 计算每个node的前置dep的端点是什么
    # node->i  node_dep_dict[i] = [node]
    #node_dep_dict = node_dep_func(dep_list, node_list)
    seq = seq_list
    stage_dict = []
    controll_dict = []
    table_cache = {} # {tbl1_name:[s1,s2...], tbl2_name:[s1,w2...]}
    table_controll_cache = {}  # {tbl1_name:{'c':1, 'u':, 'v':}, ...}
    TCAM_x = {}
    SRAM_x = {}
    ALU_x = {}
    u_x = {}
    v_x = {}
    
    for i in range(len(seq)):
        # node_name -> seq[i] 
        #print('^^^^^^^^^^^^^^^部署信息^^^^^^^^^^^^^^^^^^^^')
        #print('stage_dict', stage_dict)
        #print('table_cache', table_cache)
        
        node = seq[i]
        max_stage = 0
        # 找到端点i的所有与其有dep的端点j
        #print(seq[i])
        #print(node_dep_dict[seq[i]])
        controller_fail_flag = 0
        
        
        # max_stage的逻辑
        # 1、如果node前面有dep，则stage=max(dep_node_list)
        # 2、如果node的dep_node部署在c上，即table_cache[dep_node] = [c]，则stage=无所谓
        # 3、如果node必须的c资源没有了，则需要新增一个交换机，直到搜索到有资源的交换机时，此时stage=sw_id*12
        for j in node_dep_dict[seq[i]]:    
            if(j not in list(table_cache.keys()) and j not in list(table_controll_cache.keys())):
                print('前面的table还没有部署呢')
            if(j in list(table_cache.keys())):
                max_stage = max(max(table_cache[j])+1, max_stage)
            else:
                continue
        
        controller_num = int(max_stage/12)
        
        # 一、 部署控制平面
        controller_temp = {'table':[], 'u':100, 'v':40}
        if (node_memory_total[node.split('#')[0]]['bi'] == 0 and node_memory_total[node.split('#')[0]]['c'] == 0):
            # 正常sw node， b=0 c=0
            None
            
        else:
            
            if(node_memory_total[node.split('#')[0]]['bi'] == 1 and node_memory_total[node.split('#')[0]]['c'] == 1):               
                #不存在这种情况 b=1 c=1
                None
            else:                               
                # 判断controller是否有资源并进行部署
                while(True):
                    try:
                        aa = controll_dict[controller_num]
                    except:
                        controll_dict.append(copy.deepcopy(controller_temp))
                        
                    if(u_table_list[node.split('#')[0]] > controll_dict[controller_num]['u'] \
                       or v_table_list[node.split('#')[0]] > controll_dict[controller_num]['v']):
                        # 资源不够，下一个controller
                        controller_num = controller_num + 1
                        # 如果服务器不够用，则附加stage部署在sw上
                        if(controller_num >= len(sub_resouce)):
                            controller_fail_flag = 1
                            break
                        continue
                    else:
                        # 资源充足，部署,记录结果
                        controll_dict[controller_num]['u'] = controll_dict[controller_num]['u'] - u_table_list[node.split('#')[0]]
                        u_x[node] = [controller_num, u_table_list[node.split('#')[0]]]
                        controll_dict[controller_num]['v'] = controll_dict[controller_num]['v'] - v_table_list[node.split('#')[0]]
                        v_x[node] = [controller_num, v_table_list[node.split('#')[0]]]
                        table_controll_cache[node] = {'c':controller_num, \
                                                  'u':u_table_list[node.split('#')[0]], \
                                                  'v':v_table_list[node.split('#')[0]],\
                                                'bi': node_memory_total[node.split('#')[0]]['bi']}
                        controll_dict[controller_num]['table'].append(node)
                        break
                if(node_memory_total[node.split('#')[0]]['bi'] == 0 or controller_fail_flag == 1):
                    # b = 0 c = 1 : 有固定CPU消耗,需要继续部署在sw上
                    # 当controller没有资源部署时，需要部署在sw上
                    max_stage = max(controller_num*12, max_stage)
                if(node_memory_total[node.split('#')[0]]['bi'] == 1):
                    # b = 1 c = 0 :部署在controller上，不会继续部署在sw上
                    continue
                        
        # 二、 部署数据平面
        number_stage = max_stage
        #print(seq[i])
        
        dict_temp = {'table':[], 'SRAM':40, 'TCAM':6, 'ALU':4}
        try:
            aa = stage_dict[number_stage]
        except:
            stage_dict.append(copy.deepcopy(dict_temp))
        sram = node_memory_total[node.split('#')[0]]['SRAM']
        tcam = node_memory_total[node.split('#')[0]]['TCAM']
        alu = node_memory_total[node.split('#')[0]]['ALU']
        if(sram==0 and tcam==0 and alu==0):
            stage_dict[number_stage]['table'].append(node)
            try:
                table_cache[node].append(number_stage)
            except:
                table_cache[node] = []
                table_cache[node].append(number_stage)
            #table_record[node][number_stage] = {'SRAM':0, 'TCAM':0, 'ALU':0}
            continue
        iter_flag = 0
        while(sram != 0 or tcam != 0 or alu != 0):   
            #不满足部署条件
            #if(seq[i] == 'cache_hh#22*23'):
            #        print('cache_hh#22*23:', number_stage)
            if((alu>0 and stage_dict[number_stage]['ALU']==0 ) or (sram>0 and stage_dict[number_stage]['SRAM'] == 0) or (tcam>0 and stage_dict[number_stage]['TCAM'] == 0)):
                
                number_stage = number_stage + 1
                try:
                    aa = stage_dict[number_stage]
                except:
                    stage_dict.append({'table':[], 'SRAM':40, 'TCAM':6, 'ALU':4})
                #print(stage_dict)
            #满足部署的条件
            else:
                if(stage_dict[number_stage]['TCAM'] !=0 or stage_dict[number_stage]['SRAM'] !=0 or stage_dict[number_stage]['ALU'] !=0):
                    #table_record[node][number_stage] = {}
                    #table_record[node][number_stage]['ALU'] = alu
                    #stage_dict[number_stage]['ALU'] = stage_dict[number_stage]['ALU'] - alu
                    #alu = 0
                    
                    if(alu>= stage_dict[number_stage]['ALU']):
                        try:
                            aaa =  ALU_x[node]
                            ALU_x[node].append(number_stage)
                            ALU_x[node].append(stage_dict[number_stage]['ALU'])
                        except:
                            ALU_x[node] = [number_stage, stage_dict[number_stage]['ALU']]
                        alu = alu - stage_dict[number_stage]['ALU']
                        stage_dict[number_stage]['ALU'] = 0
                    else:
                        try:
                            aaa =  ALU_x[node]
                            ALU_x[node].append(number_stage)
                            ALU_x[node].append(alu)
                        except:
                            ALU_x[node] = [number_stage, alu]
                        stage_dict[number_stage]['ALU'] = stage_dict[number_stage]['ALU']- alu
                        alu = 0
                    
                    if(sram >= stage_dict[number_stage]['SRAM']):
                        #record
                        #table_record[node][number_stage]['SRAM'] = stage_dict[number_stage]['SRAM']
                        try:
                            aaa =  SRAM_x[node]
                            SRAM_x[node].append(number_stage)
                            SRAM_x[node].append(stage_dict[number_stage]['SRAM'])
                        except:
                            SRAM_x[node] = [number_stage, stage_dict[number_stage]['SRAM']]
                        #tcam = tcam - stage_dict[number_stage]['TCAM']
                        #stage_dict[number_stage]['TCAM'] = 0
                        sram = sram - stage_dict[number_stage]['SRAM']
                        stage_dict[number_stage]['SRAM'] = 0
                    else:
                        #record
                        #table_record[node][number_stage]['SRAM'] = sram
                        try:
                            aaa =  SRAM_x[node]
                            SRAM_x[node].append(number_stage)
                            SRAM_x[node].append(sram)
                        except:
                            SRAM_x[node] = [number_stage, sram]
                        stage_dict[number_stage]['SRAM'] = stage_dict[number_stage]['SRAM'] - sram
                        sram = 0
                    if(tcam >= stage_dict[number_stage]['TCAM']):
                        #record
                        #table_record[node][number_stage]['TCAM'] = stage_dict[number_stage]['TCAM']
                        try:
                            aaa =  TCAM_x[node]
                            TCAM_x[node].append(number_stage)
                            TCAM_x[node].append(stage_dict[number_stage]['TCAM'])
                        except:
                            TCAM_x[node] = [number_stage, stage_dict[number_stage]['TCAM']]
                        
                        tcam = tcam - stage_dict[number_stage]['TCAM']
                        stage_dict[number_stage]['TCAM'] = 0
                        
                    else:
                        #record
                        #table_record[node][number_stage]['TCAM'] = tcam
                        try:
                            aaa =  TCAM_x[node]
                            TCAM_x[node].append(number_stage)
                            TCAM_x[node].append(tcam)
                        except:
                            TCAM_x[node] = [number_stage, tcam]
                        
                        stage_dict[number_stage]['TCAM'] = stage_dict[number_stage]['TCAM'] - tcam
                        tcam = 0
                    #### add stage in node
                    #g.vertList[node].stage.append(number_stage)
                    stage_dict[number_stage]['table'].append(node)
                    try:
                        table_cache[node].append(number_stage)
                    except:
                        table_cache[node] = []
                        table_cache[node].append(number_stage)
                if(iter_flag == 1):
                    number_stage = number_stage + 1
                    try:
                        aa = stage_dict[number_stage]
                    except:
                        stage_dict.append({'table':[], 'SRAM':40, 'TCAM':6, 'ALU':4})
            iter_flag = 1
    return stage_dict, table_cache, controll_dict, table_controll_cache, {'TCAM':TCAM_x, 'SRAM':SRAM_x, 'ALU':ALU_x, 'u':u_x, 'v':v_x}

def min_max(num_list, num):
    return (num-min(num_list))/(max(num_list)-min(num_list))

def weight_sort(policy_num, dep, v, u):
    # 选择策略 1：最大吞吐量 2：最小stage 3：最小CPU load 
    seq_dict = {}
    
    if(policy_num == 1): # v
        for node in dep.keys():
            #seq_dict[node] = dep[node] + v[node]*3 + u[node]
            seq_dict[node] = dep[node]
    elif(policy_num == 2): # s
        for node in dep.keys():
            #seq_dict[node] = dep[node]*3 + v[node] + u[node]
            seq_dict[node] = dep[node]
    elif(policy_num == 3): # u
        for node in dep.keys():
            #seq_dict[node] = dep[node] + v[node] + u[node]*3
            seq_dict[node] = dep[node]
    else:
        print('policy error')
        aaa[1] = 1
    # sort
    sorted_dict = dict(sorted(seq_dict.items(), key=lambda x: x[1], reverse=True))
    
    return list(sorted_dict.keys())

def FFL_seq(dep_list, node_list, policy_num=1):
    
    # 计算放置顺序
    # 选择策略 1：最大吞吐量 2：最小stage 3：最小CPU load 
    # metrics: 1. cost = dep + memory 2. v (controller traffic) 3. u (cpu load) 
    dep_dict = {}
    all_nf_nodes = []
    cost = {}
    v_dict = {}
    u_dict = {}
    
    # 查看dep_list和node_list的结构，
    for nf_nodes in node_list:
        # 第几个nf
        nf_num = node_list.index(nf_nodes)
        for node in nf_nodes.keys():
            if(node in all_nf_nodes):
                print('node已存在，错误！！')
                aaaaa[11] = 1
            else:
                all_nf_nodes.append(node)
            # 取出dep
            dep = 0
            for i in range(nf_nodes[node], len(nf_nodes)):
                for j in range(i+1):
                    dep = dep + dep_list[nf_num][i][j]
            dep_dict[node] = dep
            # 取出storage
            #dep_dict[node] = dep_dict[node] + node_memory_total[node.split('#')[0]]['SRAM']/40
            #dep_dict[node] = dep_dict[node] + node_memory_total[node.split('#')[0]]['TCAM']/6
            dep_dict[node] = dep_dict[node] + node_memory_total[node.split('#')[0]]['ALU']
            # 取出v
            try:
                v_dict[node] = v_table_list[node.split('#')[0]]
            except:
                v_dict[node] = 0
            # 取出u 
            try:
                u_dict[node] = u_table_list[node.split('#')[0]]
            except:
                u_dict[node] = 0
                
    # 计算min-max nomalization
    
    dep_dict_value = copy.deepcopy(list(dep_dict.values()))
    #print(dep_dict)
    #print(dep_dict_value)
    u_dict_value = copy.deepcopy(list(u_dict.values()))
    v_dict_value = copy.deepcopy(list(v_dict.values()))
    for i in dep_dict.keys():
        dep_dict[i] = min_max(dep_dict_value, dep_dict[i])
        u_dict[i] = min_max(u_dict_value, u_dict[i])
        v_dict[i] = min_max(v_dict_value, v_dict[i])
        
    seq_list = weight_sort(policy_num, dep_dict, v_dict, u_dict)
    
    return seq_list

def stage_len(stage_dict):
    len_1 = 0
    table_list = []
    number = 0
    for s in stage_dict:
        if(s['table'] != [] and s['table'] != ['error']):
            len_1 = len_1 + 1
            number = number + len(s['table'])
            for i in s['table']:
                table_list.append(i)
    print('stage的长度为：', len_1)
    print('table的数量为：', number)
    return len_1
def constr_list(list):
    for i in range(len(list)):
        if list[i]['table'] == []:
            continue
        else:
            #print('stage_',i,'_:',list[i]['table'])
            print('stage_',i,'_:',list[i]['table'],'remain resource: SRAM:', list[i]['SRAM'],'TCAM:',list[i]['TCAM'],'ALU:',list[i]['ALU'])

def greedy_decomposition_thr(seq_list, dep_list, node_list, sub_resouce, node_dep_dict):
    # greedy_decomposition(g, seq, M, tbl_dict)
    # M 是CFG的dep M， tbl_dict是node:index，对应dep_m的标号
    # seq 是CFG的node
    TCAM_x = {}
    SRAM_x = {}
    ALU_x = {}
    u_x = {}
    v_x = {}
    # 2. 计算每个node的前置dep的端点是什么
    # node->i  node_dep_dict[i] = [node]
    #node_dep_dict = node_dep_func(dep_list, node_list)
    seq = seq_list
    stage_dict = []
    controll_dict = []
    table_cache = {} # {tbl1_name:[s1,s2...], tbl2_name:[s1,w2...]}
    table_controll_cache = {}  # {tbl1_name:{'c':1, 'u':, 'v':}, ...}
    for i in range(len(seq)):
        # node_name -> seq[i] 
        #print('^^^^^^^^^^^^^^^部署信息^^^^^^^^^^^^^^^^^^^^')
        #print('stage_dict', stage_dict)
        #print('table_cache', table_cache)
        sw_fail_flag = 0
        node = seq[i]
        max_stage = 0
        # 找到端点i的所有与其有dep的端点j
        #print(seq[i])
        #print(node_dep_dict[seq[i]])
        #controller_fail_flag = 0
        
        
        # max_stage的逻辑
        # 1、如果node前面有dep，则stage=max(dep_node_list)
        # 2、如果node的dep_node部署在c上，即table_cache[dep_node] = [c]，则stage=无所谓
        # 3、如果node必须的c资源没有了，则需要新增一个交换机，直到搜索到有资源的交换机时，此时stage=sw_id*12
        for j in node_dep_dict[seq[i]]:    
            if(j not in list(table_cache.keys()) and j not in list(table_controll_cache.keys())):
                print('*****')
                print(seq[i])
                print(j)
                print('-----')
                print('前面的table还没有部署呢')
            if(j in list(table_cache.keys())):
                max_stage = max(max(table_cache[j])+1, max_stage)
            else:
                continue
        
        controller_num = int(max_stage/12)
        
        # 一、 部署控制平面
        controller_temp = {'table':[], 'u':100, 'v':40}
        if (node_memory_total[node.split('#')[0]]['bi'] == 0 and node_memory_total[node.split('#')[0]]['c'] == 0):
            # 正常sw node， b=0 c=0
            None
            
        else:
            
            if(node_memory_total[node.split('#')[0]]['bi'] == 1 and node_memory_total[node.split('#')[0]]['c'] == 1):               
                #不存在这种情况 b=1 c=1
                None
            else:                               
                # 判断controller是否有资源并进行部署
                if(node_memory_total[node.split('#')[0]]['bi'] == 0 and node_memory_total[node.split('#')[0]]['c'] == 1):
                    # 必须在sw上，但是有 u和v
                    while(True):
                        try:
                            aa = controll_dict[controller_num]
                        except:
                            controll_dict.append(copy.deepcopy(controller_temp))
                            
                        if(u_table_list[node.split('#')[0]] > controll_dict[controller_num]['u'] \
                           or v_table_list[node.split('#')[0]] > controll_dict[controller_num]['v']):
                            # 资源不够，下一个controller
                            controller_num = controller_num + 1
                            # 如果服务器不够用，则附加stage部署在sw上
                            if(controller_num >= len(sub_resouce)):
                                print('控制器无资源，扑街！！！')
                                aaaaa[1] = 1
                                break
                            continue
                        else:
                            # 资源充足，部署,记录结果
                            controll_dict[controller_num]['u'] = controll_dict[controller_num]['u'] - u_table_list[node.split('#')[0]]
                            u_x[node] = [controller_num, u_table_list[node.split('#')[0]]]
                            controll_dict[controller_num]['v'] = controll_dict[controller_num]['v'] - v_table_list[node.split('#')[0]]
                            v_x[node] = [controller_num, v_table_list[node.split('#')[0]]]
                            table_controll_cache[node] = {'c':controller_num, \
                                                  'u':u_table_list[node.split('#')[0]], \
                                                  'v':v_table_list[node.split('#')[0]],\
                                                'bi': node_memory_total[node.split('#')[0]]['bi']}
                            controll_dict[controller_num]['table'].append(node)
                            break
                #if(node_memory_total[node.split('#')[0]]['bi'] == 0 or controller_fail_flag == 1):
                    # b = 0 c = 1 : 有固定CPU消耗,需要继续部署在sw上
                    # 当controller没有资源部署时，需要部署在sw上
                    max_stage = max(controller_num*12, max_stage)
                #if(node_memory_total[node.split('#')[0]]['bi'] == 1):
                    # b = 1 c = 0 :部署在controller上，不会继续部署在sw上
                    #continue
                        
        # 二、 部署数据平面
        number_stage = max_stage
        #print(seq[i])
        
        dict_temp = {'table':[], 'SRAM':40, 'TCAM':6, 'ALU':4}
        try:
            aa = stage_dict[number_stage]
        except:
            stage_dict.append(copy.deepcopy(dict_temp))
        sram = node_memory_total[node.split('#')[0]]['SRAM']
        tcam = node_memory_total[node.split('#')[0]]['TCAM']
        alu = node_memory_total[node.split('#')[0]]['ALU']
        if(sram==0 and tcam==0 and alu==0):
            stage_dict[number_stage]['table'].append(node)
            try:
                table_cache[node].append(number_stage)
            except:
                table_cache[node] = []
                table_cache[node].append(number_stage)
            #table_record[node][number_stage] = {'SRAM':0, 'TCAM':0, 'ALU':0}
            continue
        iter_flag = 0
        while(sram != 0 or tcam != 0 or alu != 0):   
            #不满足部署条件
            #if(seq[i] == 'cache_hh#22*23'):
            #        print('cache_hh#22*23:', number_stage)
            if((alu>0 and stage_dict[number_stage]['ALU']==0 ) or (sram>0 and stage_dict[number_stage]['SRAM'] == 0) or (tcam>0 and stage_dict[number_stage]['TCAM'] == 0)):
                
                number_stage = number_stage + 1
                if(number_stage >= len(sub_resouce)*12):
                    print('stage 耗尽')
                    print(node)
                    sw_fail_flag = 1
                    break
                try:
                    aa = stage_dict[number_stage]
                except:
                    stage_dict.append({'table':[], 'SRAM':40, 'TCAM':6, 'ALU':4})
                #print(stage_dict)
            #满足部署的条件
            else:
                if(stage_dict[number_stage]['TCAM'] !=0 or stage_dict[number_stage]['SRAM'] !=0 or stage_dict[number_stage]['ALU'] !=0):
                    #table_record[node][number_stage] = {}
                    #table_record[node][number_stage]['ALU'] = alu
                    #stage_dict[number_stage]['ALU'] = stage_dict[number_stage]['ALU'] - alu
                    #alu = 0
                    
                    if(alu>= stage_dict[number_stage]['ALU']):
                        try:
                            aaa =  ALU_x[node]
                            ALU_x[node].append(number_stage)
                            ALU_x[node].append(stage_dict[number_stage]['ALU'])
                        except:
                            ALU_x[node] = [number_stage, stage_dict[number_stage]['ALU']]
                        alu = alu - stage_dict[number_stage]['ALU']
                        stage_dict[number_stage]['ALU'] = 0
                    else:
                        try:
                            aaa =  ALU_x[node]
                            ALU_x[node].append(number_stage)
                            ALU_x[node].append(alu)
                        except:
                            ALU_x[node] = [number_stage, alu]
                        stage_dict[number_stage]['ALU'] = stage_dict[number_stage]['ALU']- alu
                        alu = 0
                    
                    if(sram >= stage_dict[number_stage]['SRAM']):
                        #record
                        #table_record[node][number_stage]['SRAM'] = stage_dict[number_stage]['SRAM']
                        try:
                            aaa =  SRAM_x[node]
                            SRAM_x[node].append(number_stage)
                            SRAM_x[node].append(stage_dict[number_stage]['SRAM'])
                        except:
                            SRAM_x[node] = [number_stage, stage_dict[number_stage]['SRAM']]
                        sram = sram - stage_dict[number_stage]['SRAM']
                        stage_dict[number_stage]['SRAM'] = 0
                    else:
                        #record
                        #table_record[node][number_stage]['SRAM'] = sram
                        try:
                            aaa =  SRAM_x[node]
                            SRAM_x[node].append(number_stage)
                            SRAM_x[node].append(sram)
                        except:
                            SRAM_x[node] = [number_stage, sram]
                        stage_dict[number_stage]['SRAM'] = stage_dict[number_stage]['SRAM'] - sram
                        sram = 0
                    if(tcam >= stage_dict[number_stage]['TCAM']):
                        #record
                        #table_record[node][number_stage]['TCAM'] = stage_dict[number_stage]['TCAM']
                        try:
                            aaa =  TCAM_x[node]
                            TCAM_x[node].append(number_stage)
                            TCAM_x[node].append(stage_dict[number_stage]['TCAM'])
                        except:
                            TCAM_x[node] = [number_stage, stage_dict[number_stage]['TCAM']]
                        tcam = tcam - stage_dict[number_stage]['TCAM']
                        stage_dict[number_stage]['TCAM'] = 0
                    else:
                        #record
                        #table_record[node][number_stage]['TCAM'] = tcam
                        try:
                            aaa =  TCAM_x[node]
                            TCAM_x[node].append(number_stage)
                            TCAM_x[node].append(tcam)
                        except:
                            TCAM_x[node] = [number_stage, tcam]
                        stage_dict[number_stage]['TCAM'] = stage_dict[number_stage]['TCAM'] - tcam
                        tcam = 0
                    #### add stage in node
                    #g.vertList[node].stage.append(number_stage)
                    stage_dict[number_stage]['table'].append(node)
                    try:
                        table_cache[node].append(number_stage)
                    except:
                        table_cache[node] = []
                        table_cache[node].append(number_stage)
                if(iter_flag == 1):
                    number_stage = number_stage + 1
                    if(number_stage >= len(sub_resouce)*12):
                        print('stage 耗尽')
                        print(node)
                        sw_fail_flag = 1
                        break
                    try:
                        aa = stage_dict[number_stage]
                    except:
                        stage_dict.append({'table':[], 'SRAM':40, 'TCAM':6, 'ALU':4})
            iter_flag = 1
        if(sw_fail_flag == 1 and node_memory_total[node.split('#')[0]]['bi']==1):
            # 部署在controller上  
            number_stage = max_stage
            controller_num = int(max_stage/12)
            while(True):
                try:
                    aa = controll_dict[controller_num]
                except:
                    controll_dict.append(copy.deepcopy(controller_temp))
                    
                if(u_table_list[node.split('#')[0]] > controll_dict[controller_num]['u'] \
                   or v_table_list[node.split('#')[0]] > controll_dict[controller_num]['v']):
                    # 资源不够，下一个controller
                    controller_num = controller_num + 1
                    # 如果服务器不够用，则附加stage部署在sw上
                    if(controller_num >= len(sub_resouce)):
                        print('控制器无资源，扑街！！！')
                        aaaaa[1] = 1
                        break
                    continue
                else:
                    # 资源充足，部署,记录结果
                    controll_dict[controller_num]['u'] = controll_dict[controller_num]['u'] - u_table_list[node.split('#')[0]]
                    u_x[node] = [controller_num, u_table_list[node.split('#')[0]]]
                    controll_dict[controller_num]['v'] = controll_dict[controller_num]['v'] - v_table_list[node.split('#')[0]]
                    v_x[node] = [controller_num, v_table_list[node.split('#')[0]]]
                    table_controll_cache[node] = {'c':controller_num, \
                                                  'u':u_table_list[node.split('#')[0]], \
                                                  'v':v_table_list[node.split('#')[0]],\
                                                'bi': node_memory_total[node.split('#')[0]]['bi']}
                    controll_dict[controller_num]['table'].append(node)
                    break
            
            
        elif(sw_fail_flag == 1 and node_memory_total[node.split('#')[0]]['bi']==0):
            # 只能部署在sw的node无法部署sw，sw资源不够
            print('只能部署在sw的node无法部署sw，sw资源不够')
            print(table_cache)
            aaaa[1] = 11
        
    return stage_dict, table_cache, controll_dict, table_controll_cache, {'TCAM':TCAM_x, 'SRAM':SRAM_x, 'ALU':ALU_x, 'u':u_x, 'v':v_x}