from topology.node import Node


class Link:
    
    def __init__(self, src: Node, dst: Node, bw, lat, max_bw=None, igp=0, fiber_map_spectrum=None, cost=None):
        self.src = src
        self.dst = dst
        self.bw = bw
        self.initial_bw = bw
        self.lat = lat
        self.initial_lat = lat
        self.cost = cost

    def reset(self):
        self.bw = self.initial_bw
        self.lat = initial_lat
