# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 21:46:42 2022

@author: 82633
"""
import graph_c
import random
from graphviz import Digraph
import graphviz
import time
import datetime
import copy

cpu_fixed_resource = {'LOAD':100, 'BW':10}

# stage计算等于max(s, s(f2_tbl)+11, s(aes2_tbl)+11)

def graph_show(SFC):
    g = SFC
    edge_list = {}
    vertex_list = []
    for v in g.vertList.values():
        #print(v.id)
        vertex_list.append(v)
        for w in v.getConnections():
            #print(w)
            try:
                edge_list[v.getId()].append(w.getId())
            except:
                edge_list[v.getId()] = []
                edge_list[v.getId()].append(w.getId())
    dot = Digraph(comment='The Test Table')
    for i in range(len(vertex_list)):
        sfc_id_temp = ''
        for xx in vertex_list[i].getSFCId():
            sfc_id_temp = sfc_id_temp +'('+ xx+')'
        reg_str = ''
        for reg_node in vertex_list[i].reg.keys():
            reg_str = reg_str + reg_node
        dot.node(str(vertex_list[i].getId()), str(vertex_list[i].getId())+\
                 sfc_id_temp+'||'+ reg_str+'$$'+str(vertex_list[i].stage)+\
                     str(vertex_list[i].SRAM)+'^'+str(vertex_list[i].TCAM))
    for key,value in edge_list.items():
        for ii in value:
            dot.edge(str(key), str(ii),'-')
    #print(vertex_list)
    dot.view()
    #print(dot.source)
    
    
def graph_show_dep(SFC):
    g = SFC
    edge_list = {}
    vertex_list = []
    for v in g.vertList.values():
        vertex_list.append(v)
        for w, link_dep in v.connectedTo.items():
            try:
                edge_list[v.getId()][w.getId()] = link_dep
            except:
                edge_list[v.getId()] = {}
                edge_list[v.getId()][w.getId()] = link_dep
    dot = Digraph(comment='The Test Table')
    for i in range(len(vertex_list)):
        sfc_id_temp = ''
        for xx in vertex_list[i].getSFCId():
            sfc_id_temp = sfc_id_temp +'('+ xx+')'
        reg_str = ''
        for reg_node in vertex_list[i].reg.keys():
            reg_str = reg_str + reg_node
        dot.node(str(vertex_list[i].getId()), str(vertex_list[i].getId())+\
                 sfc_id_temp+'||'+ reg_str+'$$stage:'+str(vertex_list[i].stage)+\
                     str(vertex_list[i].SRAM)+'^'+str(vertex_list[i].TCAM))
    
    for v,w_dict in edge_list.items():
        for w_node, link_dep in w_dict.items():
            dot.edge(str(v), str(w_node), str(link_dep))
    dot.view()

    



condiction_id = {'HH2_con1':'meta.custom_metadata.count_val1 > 16w100 && meta.custom_metadata.count_val2 > 16w100',
                'flowlet_con_1': 'meta.ingress_metadata.flow_ipg > 32w50000',
                 'SYN_HH_con1': 'tcp.flag==SYN', 
                 'SYN_HH_con2':'ingress_metadata.hh_count_read==threshold',
                 'UDP_flood_con_1': 'addCon(proto==UDP)',
                 'UDP_flood_con_2': 'ingress_metadata.udp_count_read==threshold',
                 'qos_con_1':'hdr.ipv4.protocol=udp',
                 'qos_con_2':'hdr.ipv4.protocol=tcp',
                 'flow_size_con_1':'',
                 'flow_size_con_2':'',
                 'spread_con_1':'',
                 'spread_con_2':'',                 
                 'HH2_con1_2':'meta.custom_metadata.count_val1 > 16w100 && meta.custom_metadata.count_val2 > 16w100',
                'flowlet_con_1_2': 'meta.ingress_metadata.flow_ipg > 32w50000',
                 'SYN_HH_con1_2': 'tcp.flag==SYN', 
                 'SYN_HH_con2_2':'ingress_metadata.hh_count_read==threshold',
                 'UDP_flood_con_1_2': 'addCon(proto==UDP)',
                 'UDP_flood_con_2_2': 'ingress_metadata.udp_count_read==threshold',
                 'qos_con_1_2':'hdr.ipv4.protocol=udp',
                 'qos_con_2_2':'hdr.ipv4.protocol=tcp',
                 'flow_size_con_1_2':'',
                 'flow_size_con_2_2':'',
                 'spread_con_1_2':'',
                 'spread_con_2_2':'',
                }
register_id = {
}
logic_list = []
'''
for i in logic_id.keys():
    logic_list.append(i)
for i in condiction_id.keys():
    logic_list.append(i)
'''
#  '':{'SRAM':40, 'TCAM':6, 'ALU':4},
# alu 不要超过4
'''



node_memory_total = {
                    # bi=1 可以放控制器 c=1控制器上需要处理流量 v数据包流量
                    'drop_table':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'ipv4_lpm2':{'SRAM':0, 'TCAM':2, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'hash_scrip_dstip':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'ipv4_lpm1':{'SRAM':0, 'TCAM':2, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'hash':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},        
                    'cache_hh':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'cache_tbl':{'SRAM':0, 'TCAM':18, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'nat_hh':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'nat_tbl':{'SRAM':0, 'TCAM':18, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'acl_hh':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'acl_tbl':{'SRAM':0, 'TCAM':18, 'ALU':0, 'bi':0, 'v':0 , 'c':1},  #u c
                    'hh1_tbl':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c 
                    'hh2_tbl':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'f1_tbl':{'SRAM':0, 'TCAM':12, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, # u b
                    'f2_tbl':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'aes_tbl':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, # u b
                    #'aes2_tbl':{'SRAM':0, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'SYN_HH_action1':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},
                    'SYN_HH_action2':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'UDP_flood_action_1':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'cha_tbl':{'SRAM':0, 'TCAM':0, 'ALU':48, 'bi':1, 'v':0 , 'c':0}, # u b
                    'ddos_action1':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'ddos_action2':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, # u b
                    'ddos_lpm':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'log1':{'SRAM':20, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log2':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log3':{'SRAM':20, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log4':{'SRAM':15, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log5':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log6':{'SRAM':15, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'rate1':{'SRAM':240, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0},  #u b
                    #'rate2':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate3':{'SRAM':0, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate4':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate5':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate6':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},                               
                    #'hash':{'SRAM':0, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},   
                  }
'''
node_memory_total = {
                    # bi=1 可以放控制器 c=1控制器上需要处理流量 v数据包流量
                    'drop_table':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'ipv4_lpm2':{'SRAM':0, 'TCAM':2, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'hash_scrip_dstip':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'ipv4_lpm1':{'SRAM':0, 'TCAM':2, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'hash':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},        
                    'cache_hh':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'cache_tbl':{'SRAM':0, 'TCAM':18, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'nat_hh':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'nat_tbl':{'SRAM':0, 'TCAM':18, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'acl_hh':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'acl_tbl':{'SRAM':0, 'TCAM':18, 'ALU':0, 'bi':0, 'v':0 , 'c':1},  #u c
                    'hh1_tbl':{'SRAM':20, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c 
                    'hh2_tbl':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'f1_tbl':{'SRAM':0, 'TCAM':12, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, # u b
                    'f2_tbl':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'aes_tbl':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, # u b
                    #'aes2_tbl':{'SRAM':0, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'SYN_HH_action1':{'SRAM':20, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},
                    'SYN_HH_action2':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'UDP_flood_action_1':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':1}, #u c
                    'cha_tbl':{'SRAM':0, 'TCAM':0, 'ALU':48, 'bi':1, 'v':0 , 'c':0}, # u b
                    'ddos_action1':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'ddos_action2':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, # u b
                    'ddos_lpm':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    'log1':{'SRAM':20, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log2':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log3':{'SRAM':20, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log4':{'SRAM':15, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log5':{'SRAM':1, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'log6':{'SRAM':15, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0}, #u b
                    'rate1':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':1, 'v':0 , 'c':0},  #u b
                    #'rate2':{'SRAM':80, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate3':{'SRAM':0, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate4':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate5':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0}, 
                    #'rate6':{'SRAM':40, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},                               
                    #'hash':{'SRAM':0, 'TCAM':0, 'ALU':0, 'bi':0, 'v':0 , 'c':0},   
                  }
# logic_id = {'tbl_name':1, ...}
logic_id = {'drop_table': 0,'ipv4_lpm2': 1,'hash_scrip_dstip': 2,\
            'ipv4_lpm1': 3,'hash': 4,'cache_hh': 5,'cache_tbl': 6,\
            'nat_hh': 7,'nat_tbl': 8,'acl_hh': 9,'acl_tbl': 10,\
            'hh1_tbl': 11,'hh2_tbl': 12,'f1_tbl': 13,'f2_tbl': 14,\
            'aes_tbl': 15,'SYN_HH_action1': 16,'SYN_HH_action2': 17,\
            'UDP_flood_action_1': 18,'cha_tbl': 19,'ddos_action1': 20,\
            'ddos_action2': 21,'ddos_lpm': 22,'log1': 23,'log2': 24,\
            'log3': 25,'log4': 26,'log5': 27,'log6': 28,'rate1': 29}
    

# 每个table的cpu load
u_table_list = {'cache_tbl': 1, 'nat_tbl': 0, 'acl_tbl': 0, \
                'hh1_tbl': 0, 'hh2_tbl': 0, \
                'SYN_HH_action2': 0, 'UDP_flood_action_1': 0,\
                'f1_tbl': 0, 'aes_tbl': 0, 'cha_tbl': 0, \
                'ddos_action2': 0,'log1': 1, 'log2': 0, 'log3': 0, 'log4': 0, 'log5': 0, 'log6': 0, 'rate1': 0}

# 初始化每个table的初始包处理速率
T_tbl = {'cache_tbl': 10, 'nat_tbl': 10, 'acl_tbl': 10, \
                'hh1_tbl': 10, 'hh2_tbl': 10, \
                'SYN_HH_action2': 10, 'UDP_flood_action_1': 10,\
                'f1_tbl': 5, 'aes_tbl': 5, 'cha_tbl': 5, \
                'ddos_action2': 0,'log1': 0, 'log2': 0, 'log3': 0, 'log4': 0, 'log5': 0, 'log6': 5, 'rate1': 5}

sample_t = 0.1    
# 每个table的需要上传控制器的处理速率    
v_table_list = {'cache_tbl': T_tbl['cache_tbl']*sample_t, \
                'nat_tbl': T_tbl['nat_tbl']*sample_t, \
                'acl_tbl': T_tbl['acl_tbl']*sample_t, \
                'hh1_tbl': 2.5, 'hh2_tbl': 2.5, \
                'SYN_HH_action2': T_tbl['SYN_HH_action2']*sample_t,\
                'UDP_flood_action_1': T_tbl['UDP_flood_action_1']*sample_t,\
                'f1_tbl': T_tbl['f1_tbl'], 'aes_tbl': T_tbl['aes_tbl'], 'cha_tbl': T_tbl['cha_tbl'], \
                'ddos_action2': T_tbl['ddos_action2'],\
                'log1': 0, 'log2': 0, 'log3': 0, 'log4': 0, 'log5': 0, 'log6': T_tbl['log6'],\
                'rate1': T_tbl['rate1']}

NF_list_name = ['rate', 'logist', 'ddos', 'chacha', 'float', 'aes', \
                'hh1', 'hh2', 'syn', 'udp',\
                'cache', 'nat', 'acl']

    
# obtain id
# sfc id-> #
# nf id-> *
def pop_id(id_random):
    return id_random.pop()

def nf_init_func(sfc=1):
    nf_list = []
    id_random = [i for i in range(100000)]
    id_random.reverse()
    for i in range(sfc):
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(rate_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(logist_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(ddos_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(chacha_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(float_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(aes_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(rate_init(SFC_id, nf_id))
        #
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(hh1_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(hh2_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(syn_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(udp_init(SFC_id, nf_id))
        #
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(cache_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(nat_init(SFC_id, nf_id))
        SFC_id = '#'+str(pop_id(id_random))
        nf_id = '*'+str(pop_id(id_random))
        nf_list.append(acl_init(SFC_id, nf_id))
    return nf_list
    


def rate_init(SFC_id, nf_id):
    # 6 stage SRAM:240
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('rate1'+id, SFC_id, nf_id)
    #g.addVertex('rate2'+id, SFC_id, nf_id)
    #g.addVertex('rate3'+id, SFC_id, nf_id)
    #g.addVertex('rate4'+id, SFC_id, nf_id)
    #g.addVertex('rate5'+id, SFC_id, nf_id)
    #g.addVertex('rate6'+id, SFC_id, nf_id)
    ## links
    #g.addEdge('rate1'+id, 'rate2'+id,1)
    #g.addEdge('rate2'+id, 'rate3'+id,1)
    #g.addEdge('rate3'+id, 'rate4'+id,1)
    #g.addEdge('rate4'+id, 'rate5'+id,1)
    #g.addEdge('rate5'+id, 'rate6'+id,1)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g
    
# fixed-memory
def logist_init(SFC_id, nf_id):
    # Gurobi需要特殊处理！！只要log tbl任意一张在控制器上，所有的都在控制器上
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()

    g.addVertex('log1'+id, SFC_id, nf_id)
    g.addVertex('log2'+id, SFC_id, nf_id)
    g.addVertex('log3'+id, SFC_id, nf_id)
    g.addVertex('log4'+id, SFC_id, nf_id)
    g.addVertex('log5'+id, SFC_id, nf_id)
    g.addVertex('log6'+id, SFC_id, nf_id)
    
    ## links 
    g.addEdge('log1'+id, 'log2'+id,1)
    g.addEdge('log2'+id, 'log3'+id,1)
    g.addEdge('log3'+id, 'log4'+id,1)
    g.addEdge('log4'+id, 'log5'+id,1)
    g.addEdge('log5'+id, 'log6'+id,1)

    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g
    

def ddos_init(SFC_id, nf_id):
    # ddos_lpm熵表，可以部署在控制上
    # 当ddos_lpm在控制器上，其dep就需要改变
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()

    g.addVertex('hash_scrip_dstip'+id, SFC_id, nf_id)
    g.addVertex('ddos_action1'+id, SFC_id, nf_id)
    g.addVertex('ddos_action2'+id, SFC_id, nf_id)
    g.addVertex('ddos_lpm'+id, SFC_id, nf_id)
    g.addVertex('ipv4_lpm2'+id, SFC_id, nf_id)
    
    ## links 
    g.addEdge('hash_scrip_dstip'+id, 'ddos_action1'+id,1)
    g.addEdge('ddos_action1'+id, 'ddos_action2'+id,1)
    g.addEdge('ddos_action2'+id, 'ddos_lpm'+id,1)
    g.addEdge('ddos_lpm'+id, 'ipv4_lpm2'+id,1)
    g.addEdge('ddos_action2'+id, 'ipv4_lpm2'+id,1)

    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g

def chacha_init(SFC_id, nf_id):
    # 12stage 主要消耗phv，因此不能在一台交换机上同时部署
    # 使用ALU代替这一限制
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('cha_tbl'+id, SFC_id, nf_id)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(HH1)
    return g

def float_init(SFC_id, nf_id):
    # 12stage，但是可以同时部署，stage结算时：stage计算等于max(s, s(f2_tbl)+11, s(aes2_tbl)+11)
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('f1_tbl'+id, SFC_id, nf_id)
    g.addVertex('f2_tbl'+id, SFC_id, nf_id)
    g.addEdge('f1_tbl'+id,'f2_tbl'+id, 1)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(HH1)
    return g

def aes_init(SFC_id, nf_id):
    # 12stage，但是可以同时部署，stage结算时：stage计算等于max(s, s(f2_tbl)+11, s(aes2_tbl)+11)
    # 化简版本：s
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('aes_tbl'+id, SFC_id, nf_id)
    #g.addVertex('aes2_tbl'+id, SFC_id, nf_id)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(HH1)
    return g


# monitoring
def hh1_init(SFC_id, nf_id):
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    ####add vertexes
    g.addVertex('hash'+id, SFC_id, nf_id)
    g.addVertex('hh1_tbl'+id, SFC_id, nf_id)   
    g.addVertex('ipv4_lpm1'+id, SFC_id, nf_id)   
    ###add links
    g.addEdge('hash'+id,'hh1_tbl'+id, 1)
    g.addEdge('hh1_tbl'+id, 'ipv4_lpm1'+id, 1)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(HH1)
    return g

def hh2_init(SFC_id, nf_id):
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    ####add vertexes
    g.addVertex('hash'+id, SFC_id, nf_id)
    g.addVertex('hh2_tbl'+id, SFC_id, nf_id)   
    g.addVertex('ipv4_lpm1'+id, SFC_id, nf_id)   
    ###add links
    g.addEdge('hash'+id,'hh2_tbl'+id, 1)
    g.addEdge('hh2_tbl'+id, 'ipv4_lpm1'+id, 1)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(HH1)
    return g

def syn_init(SFC_id, nf_id):
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('hash_scrip_dstip'+id, SFC_id, nf_id) 
    g.addVertex('SYN_HH_action1'+id, SFC_id, nf_id)
    hh_count_reg = []
    g.addVertex('SYN_HH_action2'+id, SFC_id, nf_id)
    hh_reg = []   
    g.addVertex('ipv4_lpm2'+id, SFC_id, nf_id)
    

    g.addEdge('hash_scrip_dstip'+id, 'SYN_HH_action1'+id, 1)
    g.addEdge('hash_scrip_dstip'+id, 'SYN_HH_action2'+id, 1)
    g.addEdge('SYN_HH_action1'+id, 'SYN_HH_action2'+id, 1)
    g.addEdge('SYN_HH_action2'+id, 'ipv4_lpm2'+id, 1)
    
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g

def udp_init(SFC_id, nf_id):
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()

    g.addVertex('hash_scrip_dstip'+id, SFC_id, nf_id)
    g.addVertex('UDP_flood_action_1'+id, SFC_id, nf_id)
    udp_count_reg = []
    g.addVertex('drop_table'+id, SFC_id, nf_id)
    g.addVertex('ipv4_lpm2'+id, SFC_id, nf_id)
    
    ## links 

    g.addEdge('hash_scrip_dstip'+id, 'UDP_flood_action_1'+id,1)
    g.addEdge('hash_scrip_dstip'+id, 'ipv4_lpm2'+id,1)
    g.addEdge('UDP_flood_action_1'+id, 'ipv4_lpm2'+id,1)
    g.addEdge('UDP_flood_action_1'+id, 'drop_table'+id,1)

    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g


# possibilty distribution
def cache_init(SFC_id, nf_id):
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('hash'+id, SFC_id, nf_id)
    g.addVertex('cache_hh'+id, SFC_id, nf_id)
    g.addVertex('cache_tbl'+id, SFC_id, nf_id)
    g.addVertex('ipv4_lpm1'+id, SFC_id, nf_id)
    g.addEdge('hash'+id, 'cache_hh'+id, 1)
    g.addEdge('cache_hh'+id, 'cache_tbl'+id, 1)
    g.addEdge('cache_tbl'+id, 'ipv4_lpm1'+id, 1)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g

def nat_init(SFC_id, nf_id):
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('hash'+id, SFC_id, nf_id)
    g.addVertex('nat_hh'+id, SFC_id, nf_id)
    g.addVertex('nat_tbl'+id, SFC_id, nf_id)
    g.addVertex('ipv4_lpm1'+id, SFC_id, nf_id)
    g.addEdge('hash'+id, 'nat_hh'+id, 1)
    g.addEdge('nat_hh'+id, 'nat_tbl'+id, 1)
    g.addEdge('nat_tbl'+id, 'ipv4_lpm1'+id, 1)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g

def acl_init(SFC_id, nf_id):
    id = str(SFC_id)+str(nf_id)
    g = graph_c.Graph()
    g.addVertex('hash'+id, SFC_id, nf_id)
    g.addVertex('acl_hh'+id, SFC_id, nf_id)
    g.addVertex('acl_tbl'+id, SFC_id, nf_id)
    g.addVertex('ipv4_lpm1'+id, SFC_id, nf_id)
    g.addEdge('hash'+id, 'acl_hh'+id, 1)
    g.addEdge('acl_hh'+id, 'acl_tbl'+id, 1)
    g.addEdge('acl_tbl'+id, 'ipv4_lpm1'+id, 1)
    for v_id, v in g.vertList.items():
        if(v.if_con_node()==0 and v_id != 'start'):
            # add TCAM SRAM
            v_id = v_id.replace(nf_id, "")
            v_id = v_id.replace(SFC_id, "")
            v.addSRAM(node_memory_total[v_id]['SRAM'])
            v.addTCAM(node_memory_total[v_id]['TCAM'])
            v.addALU(node_memory_total[v_id]['ALU'])
    #graph_show(g)
    return g

def init_sub_resouce(sw, cpu):
    # {0: {cpu1:{U,BW}, cpu2:{U,BW}...}, ...}
    # 通过sw的标识就能推导它的stage范围是多少 (id*12, (id+1)*12-1)
    sub_resouce = {}
    for i in range(sw):
        sub_resouce['sw'+str(i)] = {}
        for j in range(cpu):
            sub_resouce['sw'+str(i)]['cpu'+str(j)] = copy.deepcopy(cpu_fixed_resource)
    return sub_resouce