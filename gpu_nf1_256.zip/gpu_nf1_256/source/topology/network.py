import networkx as nx
from topology.node import Node
from topology.router import Router
from topology.link import Link
import collections, pdb, sys
from pulp import *
#import numpy as np
from topology.sw_node import SW_node
import copy

class Network:
    def __init__(self, stage_num):
        #self.routers = {}       # Set of Router objects
        self.links = {}         # Set of Link objects
        self.nodes = {}
        self.nodes_name = []
        self.stage_num = stage_num
        # init in register_link
        # 此字典保存着端点的链路信息，与topo中的node_fea_matrix密切相关，注意使用
        self.node_link_features = {} # {'A':{'AB':[lat, bw], 'AC':[lat, bw]}, 'B':..., ...}
        self.stageid_augnum = 0
        self.node2stage = {} # {'A':[0,1,2,3...], 'B':[12,13,14...]}
        self.stage2node = {}
        self.sub_network = nx.DiGraph()  # 在topo中初始化
        #self.node2node_dict 在topo中初始化
        self.recovery_link_bw = {}
        self.constant_link_max_bw = 100
        ###### mask+ ######
        self.sub_network_undire = nx.Graph()
        self.mask_n_step_list = {}
        self.maskplu_step_cache = {}
        self.after_node_dict = {}
        self.front_node_dict = {}
        ###### mask+ ######
    
    #####################新添加的函数#############################
    def reset(self):
        self.recovery_link_bw = {}
        
    ###### mask+ ######    
    def init_after_front_node_dict(self):
        # self.after_node_dict
        for n in self.sub_network:
            self.after_node_dict[n] = []
            for after_n in self.sub_network[n]:
                if(after_n not in self.after_node_dict[n]):
                    self.after_node_dict[n].append(after_n)
        # self.front_node_dict
        for k,vs in self.after_node_dict.items():
            for v in vs:
                try:
                    if(k not in self.front_node_dict[v]):
                        self.front_node_dict[v].append(k)
                except:
                    self.front_node_dict[v] = []
                    self.front_node_dict[v].append(k)
        empty_front_nodes = list(self.nodes_name - self.front_node_dict.keys())
        for node in empty_front_nodes:
            self.front_node_dict[node] = []
        
    ###### mask+ ######
    
    def register_node(self, node_name):
        self.nodes[node_name] = SW_node(node_name, self.stage_num)
        self.node2stage[node_name] = []
        for i in range(self.stage_num):
            self.node2stage[node_name].append(self.stageid_augnum)
            self.stage2node[self.stageid_augnum] = node_name
            self.stageid_augnum = self.stageid_augnum + 1
        self.nodes_name.append(node_name)
        
    def register_link(self, link_src, link_dst, link_lat, link_bw):
        link_name = link_src + link_dst
        self.links[link_name] = Link(link_src, link_dst, link_bw, link_lat)
        try:
            self.node_link_features[link_src][link_name] = [link_lat, link_bw]
        except:
            self.node_link_features[link_src] = {}
            self.node_link_features[link_src][link_name] = [link_lat, link_bw]
            
    def stage2node_init(self):
        stage2node = {}
        print('%%%%%%%%%%%%', self.node2stage)
        for node,stages in self.node2stage.items():
            for stage in stages:
                stage2node[stage]= node
        return stage2node
    
    def node2node_dict_init(self, graph):
        #生成是否可达的字典
        node2node = {}
        for node in graph:
            node2node[node] = [node]
            # 遍历所有的下一条节点
            node_list = [i for i in graph[node]]
            node2node[node].extend(node_list)
            while(node_list != []):
                node_next = []
                for n in node_list:
                    for i in graph[n]:
                        if(i not in node_next):
                            node_next.append(i)
                        if(i not in node2node[node]):
                            node2node[node].append(i)
                node_list = node_next
        self.node2node_dict = node2node
        #
        unr_nodes = copy.deepcopy(node2node)
        for key, nodes in node2node.items():
            for node in nodes:
                unr_nodes[node].append(key)
        for key in unr_nodes.keys():
            unr_nodes[key] = list(set(self.nodes_name) - set(unr_nodes[key]))
        self.unreach_nodes_dict = unr_nodes
    
    def check_node2node_exist(g, node1, node2):
        # node1 -> node2
        if(node1 == node2):
            return True
        node_list = [i for i in graph[node1]]
        #print("第一次的端点情况：", node_list)
        while(node_list != []):
            if(node2 in node_list):
                return True
            else:
                node_next = []
                for node in node_list:
                    #print("在序列中的node的情况：", node)
                    for i in graph[node]:
                        #print("后置node：", i)
                        if(i == node2):
                            return True
                        if(i not in node_next):
                            node_next.append(i)
                node_list = node_next
                #print('下一跳的端点,', node_list)
        return False 
    def check_direction(self, node1, node2):
        # 返回1 是 node1->node2  -1 是node2->node1
        if(node1 == node2):
            return 1
        if(node2 in self.node2node_dict[node1]):
            return 1
        if(node1 in self.node2node_dict[node2]):
            return -1
        print("node1 and node2 are not reached")
        
    def find_shortest_path(self, node1, node2):
        # todo #
        # 改为ksp算法
        try:
            return nx.dijkstra_path(self.sub_network, source=node1, target=node2, weight='lat')
        except nx.NetworkXNoPath:
            print('################################################')
            print('error between node', node1, '--->', node2)
            print('################################################')
            return False
        except nx.NodeNotFound:
            print('################################################')
            print('error between node', node1, '--->', node2)
            print('################################################')
            return False
        print('################################################')
        print('error between node', node1, '--->', node2)
        print('################################################')
        return False
    
    def get_stage2node2stages(self, s):
        n_name = self.stage2node[s]
        return self.node2stage[n_name]
    
    
    def print_var(self):
        print('##### network情况 #########')
        print('##### sub link情况 #########')
        print('node_link_features:,', self.node_link_features)
        print('#####  #########')
        print('self.node2stage:,', self.node2stage)
        print('#####  #########')
        print('self.stage2node:,', self.stage2node)
        print('#####  #########')
        print('self.node2node_dict:,', self.node2node_dict)
        print('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')
        print('')
    
    
    
    