from topology.pipeline.stage import Stage

class Pipeline:
    def __init__(self, pipeline_id, stage_num):
        self.stage_num = stage_num
        self.stage_list = {}
        self.pipeline_id = pipeline_id
        for i in range(stage_num):
            self.stage_list[i] = Stage(i,pipeline_id)