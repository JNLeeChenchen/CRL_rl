

class Stage:
    def __init__(self, name, pipelineId):
        self.name = name
        self.pipelineId = pipelineId
        self.TCAM = 6
        self.SRAM = 40
        self.bw = 100
        self.latency = 2
       