from topology.pipeline.pipeline import Pipeline

class SW_node():
    def __init__(self, name, stage_num):
        self.name = name
        self.stage_num = stage_num
        self.pipeline_id = name
        self.pipeline = Pipeline(self.pipeline_id, stage_num)
