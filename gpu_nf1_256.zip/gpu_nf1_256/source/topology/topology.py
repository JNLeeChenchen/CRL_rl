from topology.network import Network
#from topology.link import Link
#from topology.router import Router
#from topology.pipeline.pipeline import Pipeline
from topology.SFC import SFC
#import sys, pdb, time, math, json
#import os
#import collections
import numpy as np
#import random as rd
import networkx as nx
import pandas as pd
#from pulp import *
import topology.KSP
import math, copy

max_tbl_num = 24
reward_factor = 0.1
ip_fea = 2 # lat bw
c_s = 5       # cost of stage
c_sw = 10     # cost of switch
c_l =  50     # cost of link
r_redunt = -1 # reward of redunt
r_s = -0.5   # reward of same stage
r_sfc = -1    # reward of sfc
stage_fea = 3
rew1 = -1*(c_s + c_sw) # stage 0 sw 0
rew2 = -1*(c_s) # stage 0 sw 1
rew3 = -1*(r_s) # stage 1 sw 1
rew4 = -1*(r_redunt) # redunt stage 1 sw 1
tbl_fea = 4

class Topology:
    def __init__(self, SFC_num):
        self.backup_sub_network = None
        self.stage_num = 12
        self.sub = Network(self.stage_num)
        # store the solution
        self.sub_sol = Network(self.stage_num)
        self.sfc = SFC(SFC_num)
        # 存放每个table在stage中的位置，以及资源情况。{tbl1:[stage i, res, stage j, res], }
        ### todo ####
        ### 在更新时需要更新入口和出口stage的信息
        # self.tbl_place 大表（big table）中有入口stage和出口stage
        self.tbl_place = {}
        #  定义在下面的函数。勿删！！！
        # features include TCAM SRAM lat bw cost
        #  self.node_fea_matrix # 勿删！！！
        # 存放RL 的fea INNPUT，与network中的node_link_features息息相关 勿删！！！
        #self.ksp_list = [
        #self.ksp_list[0] = []
        #self.init_node_features() # import_topo_from_file()中初始化
        #self.HGNN_adj_matrix()    #import_topo_from_file()中初始化
        # 存放stage中已部署的tbl
        self.tbl_in_stage = {}
        # tbl_rel_record
        self.tbl_rel_record = {}
        self.link_rel_record = {}
        #self.init_cpu_res_info()
        self.cpu_record = {}
        ## mask+ ##
        self.mask_step = 1
        ## mask+ ##
        
    # init topo features    
    def topo_preprocess(self, topo_file):
        self.import_topo_from_file(topo_file)
        self.HGNN_adj_matrix()
        self.topo_adj_matrix_init()
        # init ob_sfc_info
        self.init_ob_sfc_info()

        
    def reset(self):
        self.sub.reset()
        self.sfc.reset()
        self.tbl_place = {}
        self.tbl_in_stage = {}
        # self.sub.sub_network
        self.sub.sub_network = copy.deepcopy(self.backup_sub_network)
        # self.node_fea_matrix
        self.init_node_features()
        self.init_ob_sfc_info()
        self.tbl_rel_record = {}
        self.link_rel_record = {}
        #self.init_cpu_res_info()
        self.cpu_record = {}
        
    #******************************************************************#
    
    def init_ob_sfc_info(self):
        # 4 features per row
        # max tbl length = 24
        '''
        max_tbl_length = 24
        # 
        ob_sfc_info = np.zeros((max_tbl_length*2,self.adj_matrix.shape[0]+4))
        i = 0
        j = i+1
        num = 0
        while(num < len(self.sfc.sfc_input_seq)):
            ob_sfc_info[i][-1] = self.sfc.sfc_bw
            # lat
            ob_sfc_info[i][-3] = self.sfc.sfc_input_seq[num][2]
            ob_sfc_info[i][-4] = self.sfc.sfc_input_seq[num][1]
            # has not been placed
            ob_sfc_info[j][-2] = -1
            ob_sfc_info[j][-1] = self.sfc.tbl_max_stage[num]
            i = i + 2
            j = i + 1
            num = num + 1
        self.ob_sfc_info = ob_sfc_info
        '''
        node_occu = []
        for i in range(self.topo_adj_matrix.shape[0]):
            node_occu.append(0)
        self.node_occu = node_occu
    
    def import_topo_from_file(self, topo_file_path):
        # topo.csv拿到topo的信息，包括node名字，带宽，延迟等
        # 生成nx保存在sub中
        nx_links = []
        nx_nodes = []
        df = pd.read_excel(topo_file_path)
        for index, row in df.iterrows():
            # add sw nodes
            if row['src'] not in self.sub.nodes_name:
                self.sub.register_node(row['src'])
                nx_nodes.append(row['src'])
            if row['dst'] not in self.sub.nodes_name:
                self.sub.register_node(row['dst'])
                nx_nodes.append(row['dst'])
            # add links
            self.sub.register_link(row['src'], row['dst'], row['lat'], row['bw'])
            nx_links.append((row['src'], row['dst'], row['bw']))
        # 创建nx
        self.sub.sub_network.add_nodes_from(nx_nodes)
        #self.sub.sub_network.add_weighted_edges_from(nx_links)
        for link in self.sub.links.values():
            #self.sub.sub_network.add_edge(link.src, link.dst, attr={'lat':link.lat, 'bw':link.bw})
            self.sub.sub_network.add_edge(link.src, link.dst, lat=link.lat, bw=0, occu=0)
        self.backup_sub_network = copy.deepcopy(self.sub.sub_network)
        self.sub.node2node_dict_init(self.sub.sub_network)
        self.init_node_features()
        ############# mask+ #########
        self.sub.init_after_front_node_dict()
    
    def print_topo_info(self):
        print('######  TOPO  #########')
        print('number of switch nodes:', len(self.sub.nodes))
        
        #### num 控制打印哪个sw的stage信息
        num_id = 'A'
        for node in self.sub.nodes.values():
            print('node info', node.name)
            print('pipeline info: pipeID=', node.pipeline.pipeline_id, ' stage_number:', len(node.pipeline.stage_list))
            if num_id == node.name:
                for stage in node.pipeline.stage_list.values():
                    print('stage info: TCAM=', stage.TCAM, ' SRAM=', stage.SRAM)            
        print('number of switch links:', len(self.sub.links))
        for link in self.sub.links.values():
            print('link info: ',link.src, '-->', link.dst, ' lat=', link.lat, ' bw=', link.bw)
       
    def generate_graph(self, if_print=1):
        graph = nx.Graph()
        graph.add_nodes_from(list(self.sub.nodes.keys()))
        for link in self.sub.links.values():
            graph.add_edge(link.src, link.dst, attr_dict={'lat':link.lat, 'bw':link.bw})
        if(if_print == 1):
            pos = nx.spring_layout(graph)
            capacity = nx.get_edge_attributes(graph, 'attr_dict')
            nx.draw_networkx_nodes(graph, pos)
            nx.draw_networkx_edges(graph, pos)
            nx.draw_networkx_labels(graph, pos)
            nx.draw_networkx_edge_labels(graph,pos,capacity)
        return graph
    
    def topo_adj_matrix_init(self):
        np_array = np.full(([len(self.sub.nodes), len(self.sub.nodes)]),0)
        num_nodes_list = {} # {A:0, B:1}
        i = 0
        for key in self.sub.nodes.keys():
            num_nodes_list[key] = i
            i = i + 1
        for link in self.sub.links.values():
            src_num = num_nodes_list[link.src]
            dst_num = num_nodes_list[link.dst]
            np_array[src_num][dst_num] = 1
            np_array[dst_num][src_num] = 1
        self.topo_adj_matrix = self.normalize(np_array)
        
    def HGNN_adj_matrix(self):  
        np_array = np.full(([len(self.sub.nodes)*self.stage_num, len(self.sub.nodes)*self.stage_num]),0,dtype=np.float32)
        num_nodes_list = {} # {A:0, B:1}
        v = 0
        for key in self.sub.nodes.keys():
            num_nodes_list[key] = v
            ##############   add self-connection  #################
            for i in range(self.stage_num):
                for j in range(self.stage_num):
                    np_array[v*self.stage_num+i][v*self.stage_num+j] = 1
                    np_array[v*self.stage_num+j][v*self.stage_num+i] = 1
            v = v + 1    
        num_flag = 0
        for link in self.sub.links.values():
            src_num = num_nodes_list[link.src]
            dst_num = num_nodes_list[link.dst]
            for i in range(self.stage_num):
                for j in range(self.stage_num):
                    np_array[src_num*self.stage_num+i][dst_num*self.stage_num+j] = 1
                    np_array[dst_num*self.stage_num+j][src_num*self.stage_num+i] = 1
                    num_flag = num_flag + 1
        np_array = self.normalize(np_array)
        
        self.adj_matrix = np_array
        
    def normalize(self, mx):
        rowsum = np.array(mx.sum(1))
        r_inv = np.power(rowsum, -0.5).flatten()
        r_inv[np.isinf(r_inv)] = 0.
        r_mat_inv = np.diag(r_inv)
        mx = r_mat_inv.dot(mx)
        mx = mx.dot(r_mat_inv)
        return mx
    
    def init_node_features(self):
        np_array = np.full([len(self.sub.nodes)*self.stage_num, 6],0.0)
        # features include TCAM SRAM lat bw cost
        node_num = 0
        for node in self.sub.nodes.values():
            try:                    
                bw_list = []
                for adj_node in self.sub.sub_network.adj[node.name]:
                    bw_list.append(self.sub.sub_network.edges[node.name,adj_node]['bw'])
                stage_bw = sum(bw_list)
            except:
                stage_bw = 0
            try:                    
                lat_list = []                   
                for adj_node in self.sub.sub_network.adj[node.name]:
                    lat_list.append(self.sub.sub_network.edges[node.name,adj_node]['lat'])    
                stage_lat = min(lat_list)
            except:
                stage_lat = 0
            u_c = 100
            v_c = 10    
            for stage in node.pipeline.stage_list.values():
                np_array[node_num][0] = stage.TCAM
                np_array[node_num][1] = stage.SRAM
                np_array[node_num][2] = u_c
                np_array[node_num][4] = v_c
                # max_latency sum_bw
                # tbl_in_stage init
                self.tbl_in_stage[node_num] = []
                node_num = node_num + 1
            
        self.node_fea_matrix = np_array
        
    def get_node_features(self):
        return self.node_fea_matrix
    
    def update_node_features(self, node_list):
        node_num = 0
        for node in self.sub.nodes.values():                   
            bw_list = []
            for adj_node in self.sub.sub_network.adj[node.name]:
                bw = self.sub.sub_network.edges[node.name,adj_node]['bw']
                if(math.isinf(bw)==True):
                    #print('recovery_link_bw:', self.sub.recovery_link_bw)
                    bw = self.sub.recovery_link_bw[node.name+adj_node]
                bw_list.append(bw)
            stage_bw = sum(bw_list)
            
            for stage in node.pipeline.stage_list.values():
                self.node_fea_matrix[node_num][4] = stage_bw              
                node_num = node_num + 1
        #print(self.node_fea_matrix)
    
        
    def check_terminal(self):
        # resource exhaust, all tables already placed, dep check
        # stage资源的检查可由action得到
        # 链路的资源检查可有最短路径的结果得到
        # table的数量可由部署的action知道
        # dep需要一个函数，并且需要由最短路径的函数做交互
        # res_flag, all_tbl_flag, dep_flag = 0, 0, 0
        None
    
    def get_action_mask(self, act, type=0, btl=False):
        # =0 means infeasible action; =1 means feasible action
        # latency 无法在此考虑，应该从ksp中判断
        # res in stages
        # sub 上node的可达性是否可以放在这考虑？？？
        if(self.sfc.sfc_exer_num == 0 and self.sfc.seq_num == 0):
            self.mask_plu_dict = {}
        if(type=='init'):
            mask = mask = [1] * self.node_fea_matrix.shape[0]
            return mask
        seq_num = self.sfc.seq_num
        res_type = self.sfc.sfc_input_seq[seq_num][3]
        
        mask = [1] * self.node_fea_matrix.shape[0]
        # big tbl 不允许放在不同的sub_node上
        
        if(btl==True):
            
            mask = [0] * self.node_fea_matrix.shape[0]
            fea_stages = self.sub.get_stage2node2stages(act)
            for s in fea_stages:
                mask[s] = 1
            if(res_type == 's'):
                for i in range(len(mask)):
                    #if(self.node_fea_matrix[i][1] < self.sfc.sfc_input_seq[seq_num][1]):
                        #if(self.sfc.sfc_input_seq[seq_num][1]<self.sub.nodes['A'].pipeline.stage_list[0].SRAM):
                            #mask[i] = 0
                    if(self.node_fea_matrix[i][1] == 0):
                        mask[i] = 0
            elif(res_type == 't'):
                for i in range(len(mask)):
                    #if(self.node_fea_matrix[i][0] < self.sfc.sfc_input_seq[seq_num][2]):
                        #if(self.sfc.sfc_input_seq[seq_num][2]<self.sub.nodes['A'].pipeline.stage_list[0].TCAM):
                            #mask[i] = 0
                    if(self.node_fea_matrix[i][0] == 0):
                        mask[i] = 0
            # redun place
            tbl_name = self.sfc.return_tbl_name()
            for i in range(len(self.tbl_in_stage)):
                if(tbl_name in self.tbl_in_stage[i]):
                    if(i in fea_stages):
                        mask[i] = 1
            # remove tbl already place
            stage_redunt_place = self.tbl_place[seq_num][0::2]
            for i in stage_redunt_place:
                mask[i] = 0
            
        else:
            
            if(res_type == 's'):
                for i in range(len(mask)):
                    
                    if(self.node_fea_matrix[i][1] < self.sfc.sfc_input_seq[seq_num][1]):
                        if(self.sfc.sfc_input_seq[seq_num][1]<self.sub.nodes['A'].pipeline.stage_list[0].SRAM):
                            mask[i] = 0
                            
                            
                    if(self.node_fea_matrix[i][1] == 0 and self.sfc.sfc_input_seq[seq_num][1] != 0):
                        mask[i] = 0
            elif(res_type == 't'):
                for i in range(len(mask)):
                    if(self.node_fea_matrix[i][0] < self.sfc.sfc_input_seq[seq_num][2]):
                        if(self.sfc.sfc_input_seq[seq_num][2]<self.sub.nodes['A'].pipeline.stage_list[0].TCAM):
                            mask[i] = 0
                    if(self.node_fea_matrix[i][0] == 0 and self.sfc.sfc_input_seq[seq_num][2] != 0):
                        mask[i] = 0
            # redun place
            tbl_name = self.sfc.return_tbl_name()
            for i in range(len(self.tbl_in_stage)):
                if(tbl_name in self.tbl_in_stage[i]):
                    mask[i] = 1
        # test mask
        #print('res', mask)
	    # dep mask 
             
        tbl_num = 0
        front_tbl_list = []
        rear_tbl_list = []
        all_sub_nodes = self.sub.nodes_name
        while(tbl_num<self.sfc.seq_num):
            
        # 如果已部署的tbl与当前tbl存在dep，front_tbl -> tbl
            if(self.sfc.sfc_dep_matrix[tbl_num][self.sfc.seq_num] == 1):
                front_tbl_list.append(tbl_num)
        # 如果已部署的tbl与当前tbl存在dep，tbl -> rear_tbl
            '''
            if(self.sfc.sfc_dep_matrix[self.sfc.seq_num][tbl_num] == 1):
                rear_tbl_list.append(tbl_num)
            '''
            tbl_num = tbl_num + 1

        for tbl in front_tbl_list:
            # 当前要部署的t必须在前置端点的后面
            try:
                info = self.tbl_place[tbl]
                # 遍历最大stage值,取奇数位置的最大值，即stage最值
                assert len(info)%2 == 0
                stage = max(info[0::2])
            except:
                continue
            s_node = self.sub.stage2node[stage]
            # s_node是front_tbl所在的sub端点，其不可达的端点全部打上0
            # s_node上的端点
            for s in self.sub.node2stage[s_node]:
                if(s<=stage):
                    mask[s] = 0
            # s_node不可达的端点
            unreach_nodes = list(set(all_sub_nodes) - set(self.sub.node2node_dict[s_node]))
            
            # 为这些端点的stage打上0
            for n in unreach_nodes:
                for s in self.sub.node2stage[n]:
                    mask[s] = 0
        # test mask
        #print('dep', mask)      
        
        # sub mask

        paths = self.sfc.sfc_tbl2path[seq_num]
        unreach_list = []
        
        for path in paths:
            #print(self.sfc.unreach_dict[path],'**')
            try:
                unreach_list.extend(self.sfc.unreach_dict[path])
            except:
                None
        unreach_list = self.remove_repeat_nodes(unreach_list)
        for sub_n in unreach_list:
            # mask
            for s in self.sub.node2stage[sub_n]:
                mask[s] = 0

        # test mask
        #print('sub', mask)       
        # mask perspective
        mask_n_step_list_t = copy.deepcopy(self.sub.mask_n_step_list)
        try:
            del mask_n_step_list_t['zero']
        except:
            None
        aaaaa = []
        for i in mask_n_step_list_t.values():
            aaaaa.extend(i)
        valid_nodes = self.remove_repeat_nodes(aaaaa)
        invalid_nodes = set(list(self.sub.node2stage.keys()))-set(valid_nodes)
        for inv_n in invalid_nodes:
            for s in self.sub.node2stage[inv_n]:
                mask[s] = 0
        #print('mask_n_step', mask_n_step_list_t)
        #print('amsk', mask)
        
        # test mask
        #print('perspe', mask)
        

        ## mask+ ##
        try:        
            mask_plu_dict_keys = list(self.mask_plu_dict[seq_num].keys())
        except:
            return mask
        mask_plu_dict_keys.remove(0)
        
        for i in mask_plu_dict_keys:
            for s in self.sub.node2stage[i]:
                if(s>self.mask_plu_dict[seq_num][i]):
                    mask[s] = 0
        for i in self.mask_plu_dict[seq_num][0]:
            for s in self.sub.node2stage[i]:
                mask[s] = 0  
        ## mask+ ##
        # test mask
        #print('mask+', mask)        
        
        return mask
    ## mask+ ##
    def find_minimal_stage(self, stage_list, now_path):
        
        i = 0
        s = stage_list[i]
        while(i<len(stage_list)-1):
            i = i + 1 
            s_temp = stage_list[i]
            # 取stage的None
            s_node = self.sub.stage2node[s]
            s_temp_node = self.sub.stage2node[s_temp]
            if(now_path.index(s_temp_node)>now_path.index(s_node)):
                s = s_temp
            elif(now_path.index(s_temp_node)==now_path.index(s_node)):
                if(s>s_temp):
                    s = s_temp
        #print('minimal stage', s)
        return s
    
    def stage_subtrate_one(self, res_stage_point, now_path, now_node, path_queue, placed_stages_list):
        res_stage_point = res_stage_point - 1
        flag = 0
        ### node的添加
        #assert res_stage_point>0
        #if(res_stage_point<0):
        #if(now_node != now_path[-1]):
        #   print('now_node != now_path[-1]-->>ERROR', 'node ', now_node,' path-1 ', now_path[-1])
        
        if(res_stage_point not in self.sub.node2stage[now_node]):
            # 减掉的stage已经不在now_node中，在now_path申请新的node
            access_flag = 0
            front_list = self.sub.front_node_dict[now_node]
            if(front_list == []):
                # 无前置端点
                flag = 1
                return res_stage_point, now_node, now_path, placed_stages_list, flag
            else:
                for i in front_list:
                    if( i in now_path):
                        now_node = now_path[now_path.index(now_node)+1]
                        access_flag = 1
                        break
                if(access_flag == 1):
                    # 已访问
                    #now_node = now_path[now_path.index(now_node)+1]
                    res_stage_point = self.sub.node2stage[now_node][-1]
                    
                    
                else:
                    # 未访问
                    for new_node in front_list:
                    # 更新
                        temp_path_for_Q = copy.deepcopy(now_path)
                        temp_path_for_Q.append(new_node)
                        path_queue.insert(0, temp_path_for_Q)
                        
                    now_path = copy.deepcopy(path_queue.pop(0))
                    
                    
                    now_node = now_path[-1]
                    placed_stages_list.extend(self.sub.node2stage[now_node])
                    
                    res_stage_point = self.sub.node2stage[now_node][-1]
            
        return res_stage_point, now_node, now_path, placed_stages_list, flag
    ## mask+ ##
    
    def action_exection_of_table_placement(self, action):
                
        ###### mask+ ######
        if(self.sfc.sfc_exer_num == 0 and self.sfc.seq_num == 0):
            self.sub.mask_n_step_list = {}
            sw_name = self.sub.stage2node[action]            
            try:
                self.sub.mask_n_step_list = self.sub.maskplu_step_cache[sw_name]                
            except:
            # 构造并保存
                n = 1
                temp_node_list = [sw_name]               
                self.sub.mask_n_step_list[0] = [sw_name]
                self.sub.mask_n_step_list['zero'] = []
                while(n <= self.mask_step and temp_node_list!=[]):                   
                    self.sub.mask_n_step_list[n] = []
                    temp_node_list2 = []                   
                    while(temp_node_list != []):
                        temp_n = temp_node_list.pop(0)
                        for node in self.sub.after_node_dict[temp_n]:
                            if node not in self.sub.mask_n_step_list[n]:                                
                                self.sub.mask_n_step_list[n].append(node)                                
                                if(self.sub.after_node_dict[node] != []):
                                    temp_node_list2.append(node)                                                        
                    temp_node_list = temp_node_list2
                    n = n + 1                
                n = 1
                temp_node_list = [sw_name]
                while(n <= self.mask_step and temp_node_list!=[]):
                    try:
                        invalid_var = self.sub.mask_n_step_list[-n]
                    except:
                        self.sub.mask_n_step_list[-n] = []
                    temp_node_list2 = []
                    
                    while(temp_node_list != []):
                        temp_n = temp_node_list.pop(0)
                        for node in self.sub.front_node_dict[temp_n]:                        
                            if node not in self.sub.mask_n_step_list[-1*n]:
                                self.sub.mask_n_step_list[-1*n].append(node)
                                if(self.sub.front_node_dict[node] != []):
                                    temp_node_list2.append(node)    
                        
                    temp_node_list = temp_node_list2
                    n = n + 1
                # 构造-1节点，计算剩余空间的首节点
                all_node = [sw_name]
                for vs in self.sub.mask_n_step_list.values():
                    all_node.extend(vs)
                for a_node in all_node:
                    flag = 0
                    if(self.sub.after_node_dict[a_node] == []):
                        if(a_node not in self.sub.mask_n_step_list['zero']):
                            self.sub.mask_n_step_list['zero'].append(a_node)
                    for af_node in self.sub.after_node_dict[a_node]:
                        if(af_node in all_node):
                            flag = 1
                            break
                    if flag == 0:
                        if(a_node not in self.sub.mask_n_step_list['zero']):
                            self.sub.mask_n_step_list['zero'].append(a_node)                
                self.sub.maskplu_step_cache[sw_name] = self.sub.mask_n_step_list
        #0704       
        ###### mask+ ######
        #0704
          
        # 构建mask+
        #print('mask+')
        if(self.sfc.sfc_exer_num in self.sfc.sfc_dep_matrix_cache_sfcid_tbl.keys()):
            if(self.sfc.seq_num in self.sfc.sfc_dep_matrix_cache_sfcid_tbl[self.sfc.sfc_exer_num]):
                mask_plu_dict = {}
            #for node in self.sfc.sfc_dep_matrix_cache.keys():
                
                if(self.sfc.seq_num >= len(self.sfc.sfc_input_seq)-1):
                    node = 0
                    sfc_dep_matrix_cache = self.sfc.sfc_dep_matrix_cache_plus
                    mask_sfc_input_seq = self.sfc.sfc_input_seq_plus
                else:
                    node = self.sfc.seq_num + 1
                    sfc_dep_matrix_cache = self.sfc.sfc_dep_matrix_cache
                    mask_sfc_input_seq = self.sfc.sfc_input_seq
                #print('node', node)
                
                # 深搜保存路jing
                # 一个端点所有潜在路径都要搜索
                path_queue = [[i] for i in self.sub.mask_n_step_list['zero']]
                #print('path_queue', path_queue)
                
                path_counter = 0
                mask_plu_dict[node] = {}
                # 存放mask为0的端点
                mask_plu_dict[node][0] = []
                while(path_queue!=[]):
                # 当有新的分支出现时，now_path会更新，完成后从path_queue删除now_path
                    no_res_flag = 0
                    stage_place = {} # 存放stage已经部署的node
                    stage_temp = copy.deepcopy(self.node_fea_matrix)
                    
                    now_path = path_queue.pop(0)
                    #modify_node = {now_path:[]} # {node:[stage1, stage2], }
                    path_counter = path_counter + 1
                    placed_stages_list = []
                    for i in now_path:
                        placed_stages_list.extend(self.sub.node2stage[i])
                    
                    for i in range(len(sfc_dep_matrix_cache[node])):
                        # compute stage_point
                        ####  todo  这里的res_stage_point指向有问题###
                        # 指向第一个node的最后一个stage
                        
                        now_node = now_path[0]
                        res_stage_point = self.sub.node2stage[now_node][-1] # 标志有资源的stage
                        
                        if(mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][3] == 's'):
                            
                            while(stage_temp[res_stage_point][1] == 0):
                                
                                res_stage_point, now_node, now_path, placed_stages_list, no_res_flag = self.stage_subtrate_one(res_stage_point, now_path, now_node, path_queue, placed_stages_list)
                                if(no_res_flag == 1):
                                    print('zheli 6')
                                    break
                                
                        elif(mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][3] == 't'):
                            while(stage_temp[res_stage_point][0] == 0):
                                
                                res_stage_point, now_node, now_path, placed_stages_list, no_res_flag = self.stage_subtrate_one(res_stage_point, now_path, now_node, path_queue, placed_stages_list)
                                if(no_res_flag == 1):
                                    print('zheli 5')
                                    break
                        if(no_res_flag == 1):
                            print('zheli 4')
                            break
                        stage_point = res_stage_point
                        
                        if(i != 0):
                            try:
                                
                                n_list = copy.deepcopy(sfc_dep_matrix_cache[sfc_dep_matrix_cache[node][i]])
                                n_list.remove(sfc_dep_matrix_cache[node][i])
                                min_stage_list = []               
                                for nnn in n_list:
                                    try:
                                        min_stage_list.append(stage_place[nnn])
                                    except:
                                        continue
                                
                                if(min_stage_list == []):
                                    stage_point = res_stage_point
                                    
                                else:
                                    min_stage = self.find_minimal_stage(min_stage_list, now_path)
                                    now_node = self.sub.stage2node[min_stage]
                                    
                                    stage_point, now_node, now_path, placed_stages_list, no_res_flag = self.stage_subtrate_one(min_stage, now_path, now_node, path_queue, placed_stages_list)
                                    
                                    if(no_res_flag == 1):
                                        print('zheli 3')
                                        break
                                    
                                    
                                    
                            except:
                                stage_point = res_stage_point
                            
                            if(stage_point <0):
                                print('ERROR！！')
                                break
                            
                            
                        if(mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][3] == 's'):    
                            if(mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][1]  > stage_temp[stage_point][1]):
                                remind_memory = mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][1]
                                
                                while(remind_memory > stage_temp[stage_point][1]):
                                    remind_memory = remind_memory - stage_temp[stage_point][1]
                                    stage_temp[stage_point][1] = 0
                                    #stage_point = stage_point - 1
                                    stage_point, now_node, now_path, placed_stages_list, no_res_flag = self.stage_subtrate_one(stage_point, now_path, now_node, path_queue, placed_stages_list)
                                    if(no_res_flag == 1):
                                        print('zheli 2')
                                        break
                                    
                                stage_temp[stage_point][1] =  stage_temp[stage_point][1] - remind_memory
                                stage_place[sfc_dep_matrix_cache[node][i]] = stage_point  
                            else:
                                stage_place[sfc_dep_matrix_cache[node][i]] = stage_point
                                stage_temp[stage_point][1] = stage_temp[stage_point][1] - mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][1]
                        
                        elif(mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][3] == 't'):
                            if(mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][2]  > stage_temp[stage_point][0]):
                                remind_memory = mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][2]
                                
                                while(remind_memory > stage_temp[stage_point][0]):
                                    remind_memory = remind_memory - stage_temp[stage_point][0]
                                    stage_temp[stage_point][0] = 0
                                    #stage_point = stage_point - 1
                                    stage_point, now_node, now_path, placed_stages_list, no_res_flag = self.stage_subtrate_one(stage_point, now_path, now_node, path_queue, placed_stages_list)
                                    if(no_res_flag == 1):
                                        print('zheli 1')
                                        break
                                    
                                stage_temp[stage_point][0] =  stage_temp[stage_point][0] - remind_memory
                                stage_place[sfc_dep_matrix_cache[node][i]] = stage_point   
                            else:
                                stage_place[sfc_dep_matrix_cache[node][i]] = stage_point
                                stage_temp[stage_point][0] = stage_temp[stage_point][0] - mask_sfc_input_seq[sfc_dep_matrix_cache[node][i]][2]
                            
                    # 一条path结束后，更新mask+
                    # 只保存 maks=1 的stage信息
                    if(no_res_flag == 1):
                        #print('No resource for place')
                        #print('ybl_stage', self.tbl_in_stage)
                        for i in now_path:
                            if(i not in mask_plu_dict[node][0]):
                                mask_plu_dict[node][0].append(i)
            
                        #mask_decode = [0] * self.node_fea_matrix.shape[0]
                    else:
                        #print(stage_place)
                        try:
                            mask_position = stage_place[node]
                        except:
                            mask_position = 0
                        if(mask_position in mask_plu_dict[node][0]):
                            mask_plu_dict[node][0].remove(mask_position)
                        
                        if(now_path[-1] != self.sub.stage2node[mask_position]):
                            #print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!') 
                            #print('ERROR, not in correct mask position')
                            None
                        try:
                            temp_stage_v = mask_plu_dict[node][now_path[-1]]
                            if(temp_stage_v < mask_position):
                                mask_plu_dict[node][now_path[-1]] = temp_stage_v
                        except:
                            mask_plu_dict[node][now_path[-1]] = mask_position
                        for i in now_path[0:-1]:
                            if(i not in mask_plu_dict[node][0]):
                                mask_plu_dict[node][0].append(i)
                        
                # mask+中如果有全0的，则无法部署
                self.mask_plu_dict = mask_plu_dict
                
            
                for key in mask_plu_dict.keys():
                    node_list  = list(mask_plu_dict[key].keys())
                    node_list.remove(0)
                    if(node_list == []):
                        return 1,0,0,0,0,0
        #0703    
        ###### mask+ ######
        
        
        #print('---------Action start---------')
        seq_num = self.sfc.seq_num
        cost_dict = {'s':0, 'sw':0, 'link':0}
        #gamma = (seq_num+1)/len(self.sfc.sfc_input_seq)
        # rew->1
        #reward_tbl = 10*gamma
        
        cost = 0
        repeat_plc_flag = False
        tbl_name = self.sfc.return_tbl_name()
        #print('tbl_name:', tbl_name)
        #if(tbl_name in self.tbl_in_stage[action]):
        #    repeat_plc_flag = True
        #    self.tbl_in_stage[action].append(tbl_name)
        # stage cost, 如果已经部署，则cost为0，如果未部署，则cost为默认，并且将cost置为0
        stage_cost = self.node_fea_matrix[action][3]
        if(self.sub.stage2node[action] not in self.sfc.subnode_for_cost):
            
            self.sfc.subnode_for_cost.append(self.sub.stage2node[action])
            
        if(stage_cost == 0):
            self.node_fea_matrix[action][3] = 1
            
            if(self.node_occu[action//12] == 0):
                cost = c_s + c_sw
                cost_dict['s'] = cost_dict['s'] + c_s
                cost_dict['sw'] = cost_dict['sw'] + c_sw
                
            else:
                cost = c_s
                cost_dict['s'] = cost_dict['s'] + c_s
            
        else:
            # same stage
            cost = r_s
        
        res_flag, dep_flag, sub_flag, sat_flag, big_tbl_flag = False, False, False, False, False
        btl = False
        
        # 初试化self.tbl_palce中当前部署tbl的资源情况
        try:
            # big table必须在同一个交换机
            rel_temp = self.tbl_place[seq_num]
            action_node = self.sub.stage2node[action]
            stage_node = self.sub.stage2node[rel_temp[0]]
            if(action_node != stage_node):
                big_tbl_flag = True
                ############  TODO !!!!!!! ##################
                # cost 未定义
                cost = 1000

                ############  TODO !!!!!!! ##################
                return big_tbl_flag, res_flag, cost, sat_flag, sub_flag, dep_flag, btl, cost_dict
        except:
            self.tbl_place[seq_num] = []
        rew_res = 0
        # 1、更新stage资源，操作self.node_fea_matrix矩阵，此处要返回flag, sfc_input_seq中的资源也要减少
        #if(self.sfc.sfc_input_seq[seq_num][3] == 's' and repeat_plc_flag == False):
        if(self.sfc.sfc_input_seq[seq_num][3] == 's'):
            # consume SRAM
            if(self.node_fea_matrix[action][1] == 0):
                if(tbl_name in self.tbl_in_stage[action]):
                    cost = r_redunt
                    self.tbl_place[seq_num].append(action)
                    res_stage = self.get_redunt_res(seq_num, self.sfc.sfc_exer_num, tbl_name, action)
                    if(res_stage>self.sfc.sfc_input_seq[seq_num][1]):
                        self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][1])
                        self.sfc.sfc_input_seq[seq_num][1] = 0
                    else:
                        self.tbl_place[seq_num].append(res_stage)
                        self.sfc.sfc_input_seq[seq_num][1] = self.sfc.sfc_input_seq[seq_num][1] - res_stage
                    
                elif(self.sfc.sfc_input_seq[seq_num][1] == 0):
                    self.tbl_place[seq_num].append(action)
                    self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][1])
                    #self.ob_sfc_info[seq_num*2+1][-2] = action
                else:
                    print('impossble place &&&&&')
                self.tbl_in_stage[action].append(tbl_name)
            else:
                if(tbl_name in self.tbl_in_stage[action]):
                    cost = r_redunt
                    repeat_plc_flag = True
                    
                self.tbl_in_stage[action].append(tbl_name)
                # 这里采用贪婪的方式部署 self.node_fea_matrix[action][1]为stage资源
                # self.sfc.sfc_input_seq[seq_num][1、2] 是需要部署的资源SRAM TCAM
                if(self.node_fea_matrix[action][1] >= self.sfc.sfc_input_seq[seq_num][1]):
                    if(repeat_plc_flag == False):
                        self.node_fea_matrix[action][1] -= self.sfc.sfc_input_seq[seq_num][1]
                        self.tbl_place[seq_num].append(action)
                        self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][1])
                        self.sfc.sfc_input_seq[seq_num][1] = 0
                        #self.ob_sfc_info[seq_num*2][0] = self.sfc.sfc_input_seq[seq_num][1]
                        #self.ob_sfc_info[seq_num*2+1][-2] = action
                    else:
                        self.tbl_place[seq_num].append(action)
                        res_stage = self.get_redunt_res(seq_num, self.sfc.sfc_exer_num, tbl_name, action)
                        self.tbl_place[seq_num].append(res_stage)
                        self.sfc.sfc_input_seq[seq_num][1] = self.sfc.sfc_input_seq[seq_num][1] - res_stage
                        #self.ob_sfc_info[seq_num*2][0] = res_stage
                        #self.ob_sfc_info[seq_num*2+1][-2] = action
                    
                else:
                    if(repeat_plc_flag == False):
                        self.sfc.sfc_input_seq[seq_num][1] -= self.node_fea_matrix[action][1]

                        #self.ob_sfc_info[seq_num*2][0] = self.sfc.sfc_input_seq[seq_num][1]
                        self.tbl_place[seq_num].append(action)
                        self.tbl_place[seq_num].append(self.node_fea_matrix[action][1])
                        self.node_fea_matrix[action][1] = 0   
                        #self.ob_sfc_info[seq_num*2+1][-2] = action
                    else:
                        self.tbl_place[seq_num].append(action)
                        res_stage = self.get_redunt_res(seq_num, self.sfc.sfc_exer_num, tbl_name, action)
                        if(res_stage>self.sfc.sfc_input_seq[seq_num][1]):
                            self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][1])
                            self.sfc.sfc_input_seq[seq_num][1] = 0
                        else:
                            self.tbl_place[seq_num].append(res_stage)
                            self.node_fea_matrix[action][1] = self.sfc.sfc_input_seq[seq_num][1] - res_stage
                        

                
        #elif(self.sfc.sfc_input_seq[seq_num][3] == 't' and repeat_plc_flag == False):
        elif(self.sfc.sfc_input_seq[seq_num][3] == 't'):
           
            if(self.node_fea_matrix[action][0] == 0):
                if(tbl_name in self.tbl_in_stage[action]):
                    cost = r_redunt
                    self.tbl_place[seq_num].append(action)
                    res_stage = self.get_redunt_res(seq_num, self.sfc.sfc_exer_num, tbl_name, action)
                    if(res_stage > self.sfc.sfc_input_seq[seq_num][2]):
                        self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][2])
                        self.sfc.sfc_input_seq[seq_num][2] = 0
                    else:
                        self.tbl_place[seq_num].append(res_stage)
                        self.sfc.sfc_input_seq[seq_num][2] = self.sfc.sfc_input_seq[seq_num][2] - res_stage
                    
                elif(self.sfc.sfc_input_seq[seq_num][2] == 0):
                    self.tbl_place[seq_num].append(action)
                    self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][1])
                    #self.ob_sfc_info[seq_num*2+1][-2] = action
                else:
                    print('impossble place &&&&&')
                self.tbl_in_stage[action].append(tbl_name)
                
            else:
                # consume TCAM
                if(tbl_name in self.tbl_in_stage[action]):
                    repeat_plc_flag = True
                    cost = r_redunt
                self.tbl_in_stage[action].append(tbl_name)
                if(self.node_fea_matrix[action][0] >= self.sfc.sfc_input_seq[seq_num][2]):
                    # small tbl
                    if(repeat_plc_flag == False):
                        self.node_fea_matrix[action][0] -= self.sfc.sfc_input_seq[seq_num][2]
                                     
                        self.tbl_place[seq_num].append(action)
                        self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][2])
                        self.sfc.sfc_input_seq[seq_num][2] = 0
                        #self.ob_sfc_info[seq_num*2][1] = self.sfc.sfc_input_seq[seq_num][2]
                        #self.ob_sfc_info[seq_num*2+1][-2] = action
                    else:
                        self.tbl_place[seq_num].append(action)
                        res_stage = self.get_redunt_res(seq_num, self.sfc.sfc_exer_num, tbl_name, action)
                        self.tbl_place[seq_num].append(res_stage)
                        self.sfc.sfc_input_seq[seq_num][2] = self.sfc.sfc_input_seq[seq_num][2] - res_stage
                        #self.ob_sfc_info[seq_num*2][1] = res_stage
                        #self.ob_sfc_info[seq_num*2+1][-2] = action

                else:
                    #big tbl
                       
                    if(repeat_plc_flag == False):
                        self.sfc.sfc_input_seq[seq_num][2] -= self.node_fea_matrix[action][0]
                    # 记录部署的位置和资源情况
                        self.tbl_place[seq_num].append(action)
                        self.tbl_place[seq_num].append(self.node_fea_matrix[action][0])
                        self.node_fea_matrix[action][0] = 0
                        #self.ob_sfc_info[seq_num*2][1] = self.sfc.sfc_input_seq[seq_num][2]
                        #self.ob_sfc_info[seq_num*2+1][-2] = action
                    else:
                        self.tbl_place[seq_num].append(action)
                        res_stage = self.get_redunt_res(seq_num, self.sfc.sfc_exer_num, tbl_name, action)
                        if(res_stage > self.sfc.sfc_input_seq[seq_num][2]):
                            self.tbl_place[seq_num].append(self.sfc.sfc_input_seq[seq_num][2])
                            self.sfc.sfc_input_seq[seq_num][2] = 0
                        else:
                            self.tbl_place[seq_num].append(res_stage)
                            self.sfc.sfc_input_seq[seq_num][2] = self.sfc.sfc_input_seq[seq_num][2] - res_stage
                        
        
        # dep_check()
        # test for 
        self.tbl_rel_record[self.sfc.sfc_exer_num] = self.tbl_place
        
        dep_flag = self.dep_check_func(action)

        if(dep_flag):
            ############  TODO !!!!!!! ##################
            
            cost = 1000
            ############  TODO !!!!!!! ##################
            return big_tbl_flag, res_flag, cost, sat_flag, sub_flag, dep_flag, btl, cost_dict
        # 2、更新链路资源，包括查找最短路径等，此处要返回flag
        # todo!!!  k-shortest_path() 
        # D. Eppstein, “Finding the K shortest paths,” SIAM J. Comput., vol. 28,  no. 2, pp. 652–673, 1998.
        # 3、返回cost
        sub_flag, bw_cost, cost_dict_link, cost_dict_sw = self.sub_placement(action)
        cost_dict['link'] = cost_dict_link
        cost_dict['sw'] = cost_dict['sw'] + cost_dict_sw
        cost = bw_cost + cost
        
        if(sub_flag):
            ############  TODO !!!!!!! ##################
            
            cost = 1000
            ############  TODO !!!!!!! ##################
            return big_tbl_flag, res_flag, cost, sat_flag, sub_flag, dep_flag, btl, cost_dict
        
        # 控制当前table的输入顺序
        # 如果当前tbl的资源未完成，则继续部署该表
        if( self.sfc.sfc_input_seq[seq_num][1] == 0 and self.sfc.sfc_input_seq[seq_num][2] == 0):
            #self.ob_sfc_info[seq_num*2][-1] = 0
            #self.ob_sfc_info[seq_num*2][-2] = 0
            #self.ob_sfc_info[seq_num*2+1][-1] = 0
            self.sfc.seq_num = self.sfc.seq_num + 1
        else:
            btl = True
        # 所有tbl部署完毕
        nnode_name = self.sub.stage2node[action]
        nnode_name_index = list(self.sub.node2stage.keys()).index(nnode_name)
        self.node_occu[nnode_name_index] = 1
        
        #print(self.tbl_place)
        if(self.sfc.seq_num >= len(self.sfc.sfc_input_seq)):
            # SFC place finish and record
            cost = cost + r_sfc*(self.sfc.sfc_exer_num + 1)*2
            self.tbl_rel_record[self.sfc.sfc_exer_num] = self.tbl_place
            self.link_rel_record[self.sfc.sfc_exer_num] = self.sfc.link_ksp_dict
            
            self.sfc.sfc_exer_num = self.sfc.sfc_exer_num + 1
            if(self.sfc.sfc_exer_num >= self.sfc.SFC_number):
                sat_flag = True
                #cost = 0
                return big_tbl_flag, res_flag, cost, sat_flag, sub_flag, dep_flag, btl, cost_dict
            
            self.next_sfc_update()
        # 计算部署的cpu的需求量
        cpu_flag = self.cpu_compute()
        if(cpu_flag == 1):
            cost = 1000
            return big_tbl_flag, res_flag, cost,  sat_flag, sub_flag, 1, btl, cost_dict
        cost = cost - 100
        return big_tbl_flag, res_flag, cost, sat_flag, sub_flag, dep_flag, btl, cost_dict
        

    def cpu_compute(self):
        u = 0
        v = 0
        for i in self.tbl_place.keys():
            # max stage 所有的都放在controller上
            u = u + self.sfc.sfc_input_info[i][4]
            v = v + self.sfc.sfc_input_info[i][5]
        if(u > len(self.sub.nodes_name)*100 or v > len(self.sub.nodes_name)*10):
            return 1
        return 0

        
    def sub_placement(self, action):
        cost = 0
        cost_dict_link = 0
        cost_dict_sw = 0
        link_flag = False
        logic_flag = False
        new_node_list = [] # 存放新的link中的端点，以便于更新这些端点的bw（node_fea_matrix）
        # sub中的self.sub.node2node_dict 存放node的直达
        # SFC中的self.sfc.sfc_logit_dict 存放SFC前=向端点
        # 1.logic_flag -》可达性
        # logic_tbls存放的是tbl相连接的tbl
        
        logic_tbls = self.sfc.sfc_logit_dict[self.sfc.seq_num]
        
        # stage_node保存对应的前向端点所放置的node
        action_node = self.sub.stage2node[action]
        #big_tbl_update_flag = None
        ### ##### todo ##############
        ### 1 取出已部署的tbl，并判断是否可达
        '''
        for tbl in logic_tbls:
            try:
                #self.tbl_place 大表中有入口stage和出口stage
                info = self.tbl_place[tbl]
            except:
                continue
                # 取出连接所有stage
            assert len(info)%2 == 0
            stage = info[0::2]
            if(len(stage) == 0):
                # 即为没有被部署的tbl
                continue                        
            stage_node = []
            for s in stage:
                s_node = self.sub.stage2node[s]
                if(s_node not in stage_node):
                    stage_node.append(s_node)
                    # 判断这些放置的node是否能直达action的位置,如果不可达，则有逻辑错误
                    if(action_node not in self.sub.node2node_dict[s_node] and s_node not in self.sub.node2node_dict[action_node]):
                        logic_flag = True
                        ############  TODO !!!!!!! ##################
                        # cost 未定义
                        cost = 10000
                        #print('还是这里？')
                        ############  TODO !!!!!!! ##################
                        return logic_flag, cost
        '''    
        # 2.cost and KSP
        # 使用self.sfc.link_ksp_dict={link_id:[ksp1,ksp2,...]} 来保存virtual link的ksp
        # 2.2 tbl端点和正常端点都需要处理    
        for tbl in logic_tbls:
            try:
                # tbl是与当前部署的tbl相连接的表，查看否被部署
                info = self.tbl_place[tbl]
                stage = info[0::2]
                if(len(stage) == 0):
                # 即为没有被部署的tbl
                    continue
            except:
                continue
            
            # 取出link_name, 访问virtual link通过字典self.sfc.link_ksp_dict
            v_link_name = self.sfc.get_link_name(tbl, self.sfc.seq_num)
            # find shortst path-》 action_node and tbl_node
            # todo 这里有没有可能找KSP呢？ 
            #逻辑为，1、如果action_node在tbl_node中，则设置为NoPath
            stage2node_list = [self.sub.stage2node[s] for s in stage]
            if(action_node in stage2node_list):
                self.sfc.link_ksp_dict[v_link_name] = 'SameNode*'
            else:
                
                if(self.sub.check_direction(action_node, stage2node_list[0])==1):
                    
                    link_res = self.sub.find_shortest_path(action_node, stage2node_list[0])
                    
                else:
                    
                    link_res = self.sub.find_shortest_path(stage2node_list[0], action_node)  
                # 在nx中检查可达性 并 修改链路的bw属性
                
                for node_num in range(len(link_res)):
                    if(node_num>=len(link_res)-1):
                        break
                    u = link_res[node_num]
                    v = link_res[node_num+1]
                    
                    if(math.isinf(self.sub.sub_network.edges[u, v]['bw']) == True):
                        # 无法分配路径
                        
                        link_flag = True
                        cost = 1000
                        return link_flag, cost
                    else:
                        # 未被占用
                        if(self.sub.sub_network.edges[u, v]['occu'] ==0):
                            self.sub.sub_network.edges[u, v]['bw'] = \
                            self.sub.sub_network.edges[u, v]['bw'] + self.sfc.sfc_bw
                            self.sub.sub_network.edges[u, v]['occu'] = 1
                            cost = cost + self.sub.sub_network.edges[u, v]['lat']*c_l
                            cost_dict_link = cost_dict_link + self.sub.sub_network.edges[u, v]['lat']*c_l
                            
                    new_node_list.append(u)
                    new_node_list.append(v)
                   
                self.sfc.link_ksp_dict[v_link_name] = link_res
                #print('%%%%%%%%%%%%%%%  add new sub link for virtual link%')
                #print('%%%%%%%%%%%%%%%  sub link is: ', link_res)
                #print('%%%%%%%%%%%%%%%  virtual link is: ', v_link_name)
                
                #cost_nodes.extend(link_res)
                    
                    
            link_flag = self.check_tbl_path_flag(tbl, stage2node_list[0])
            if(link_flag == True):
                break
            # self.sfc.link_ksp_dict[v_link_name] = self.sub.find_shortest_path()
            # self.tbl_place = {tbl1:[stage i, res, stage j, res], }
            # 计算并保存此路径的ksp
            #if()
        
        new_node_list = self.remove_repeat_nodes(new_node_list)
        self.update_node_features(new_node_list)
        unreach_list = []

        if(new_node_list != []):
            for sub_n in new_node_list:
                unreach_list.extend(self.sub.unreach_nodes_dict[sub_n])
                if(sub_n not in self.sfc.subnode_for_cost):
                    cost = cost + c_sw
                    cost_dict_sw = cost_dict_sw + c_sw
                    self.sfc.subnode_for_cost.append(sub_n)
        else:
            unreach_list.extend(self.sub.unreach_nodes_dict[action_node])
        unreach_list = self.remove_repeat_nodes(unreach_list)
        # 添加到当前部署的tbl中的paths
        paths = self.sfc.sfc_tbl2path[self.sfc.seq_num]

        for path in paths:
            for node in unreach_list:
                if node not in self.sfc.unreach_dict[path]:
                    self.sfc.unreach_dict[path].append(node)
        return link_flag, cost, cost_dict_link, cost_dict_sw


    def check_tbl_path_flag(self, check_tbl, act_node):
        # 1、构造判断集合,tbl的前置端点
        check_nodes_list = self.sfc.sfc_logit_pre_dict[check_tbl]
        for tbl in check_nodes_list:
            # 这里的tbl是check_tbl的前置端点，我们需要找出已部署的前置端点，并且其link也确定了
            try:
                info = self.tbl_place[tbl]
                stage = info[0::2]
                if(len(stage) == 0):
                # 即为没有被部署的tbl
                    continue
            except:
                continue
            v_link_name = self.sfc.get_link_name(tbl, check_tbl)
            #stage2node_list = [self.sub.stage2node[s] for s in stage]
            
            node = self.sfc.link_ksp_dict[v_link_name][-1]
            if(node == '*'):
                
                continue
            if(node not in self.sub.node2node_dict[act_node] and act_node not in self.sub.node2node_dict[node]):
                return True
            node = self.sfc.link_ksp_dict[v_link_name][0]
            if(node not in self.sub.node2node_dict[act_node] and act_node not in self.sub.node2node_dict[node]):
                return True
        return False
    
    def dep_check_func(self, act):
        act_node = self.sub.stage2node[act]
        front_tbl_list = []
        rear_tbl_list = []
        tbl_num = 0
        dep_flag = False
        while(tbl_num<self.sfc.seq_num):
            # 如果已部署的tbl与当前tbl存在dep，front_tbl -> tbl
            if(self.sfc.sfc_dep_matrix[tbl_num][self.sfc.seq_num] == 1):
                front_tbl_list.append(tbl_num)
            # 如果已部署的tbl与当前tbl存在dep，tbl -> rear_tbl
            if(self.sfc.sfc_dep_matrix[self.sfc.seq_num][tbl_num] == 1):
                rear_tbl_list.append(tbl_num)
            tbl_num = tbl_num + 1

        # 在已部署的tbl中查找是否有dep， self.tbl_place
        # 两种情况，一种是前置的tbl未部署，则跳过，第二种是已部署，则有front>tbl，否则返回错误
        for tbl in front_tbl_list:
            try:
                info = self.tbl_place[tbl]
                # 遍历最大stage值,取奇数位置的最大值，即stage最值
                assert len(info)%2 == 0
                stage = max(info[0::2])
                s_node = self.sub.stage2node[stage]
                if(act_node == s_node and stage > act):
                    return True
                if(act_node not in self.sub.node2node_dict[s_node]):
                    # s_node -> act_node
                    return True
            except:
                continue
        '''    
        for tbl in rear_tbl_list:
            try:
                info = self.tbl_place[tbl]
                # 遍历最大stage值,取奇数位置的最大值，即stage最值
                assert len(info)%2 == 0
                stage = max(info[0::2])
                s_node = self.sub.stage2node[stage]
                if(act_node == s_node and act > stage):
                    return True
                if(s_node not in self.sub.node2node_dict[act_node]):
                    # act_node -> s_node
                    return True              
            except:
                continue
        '''
        return dep_flag
    
    def action_exec(self, action):
        self.sub.node_link_features['A']['AB']
        
    def next_sfc_update(self):
        # 恢复被置为inf的link
        
        
        for link,bw in self.sub.recovery_link_bw.items():
            
            self.sub.sub_network.edges[link[0],link[1]]['bw'] = bw
            
        self.sub.recovery_link_bw = {}
        # 新的SFC的部署信息
        self.sfc.seq_num = 0
        self.sfc.init_sfc_info()
        #self.init_ob_sfc_info()
        self.sfc.save_per_sfc_tbl_place[self.sfc.sfc_exer_num] = self.tbl_place
        self.tbl_place = {}
        # sub图中的link的占用初始化    
        for u,v in self.sub.sub_network.edges:
            if(self.sub.sub_network.edges[u,v]['bw'] + self.sfc.sfc_bw > self.sub.links[u+v].bw):
                #self.sub.recovery_link_bw.append([u,v, self.sub.sub_network.edges[u,v]['bw']])
                self.sub.recovery_link_bw[u+v] = self.sub.sub_network.edges[u,v]['bw']
                self.sub.sub_network.edges[u,v]['bw'] = float("inf")    
            #self.sub.sub_network.edges[u,v]['occu'] = 0
            
        
    def remove_repeat_nodes(self, repeat_llst):
        return list(set(repeat_llst))
    
    def get_observation(self, mask, sat=False):
        # obs has four parts: self.topo_matrix, ip_fea_t, ob_sfc_info_t, node_fea_t
        if(sat == False):
            sram_input = self.sfc.sfc_input_seq[self.sfc.seq_num][1]
            tcam_input = self.sfc.sfc_input_seq[self.sfc.seq_num][2]
            # self.node_fea_matrix[5] redunt
            tbl_name = self.sfc.return_tbl_name()
            for i in range(len(self.tbl_in_stage)):
                if(tbl_name in self.tbl_in_stage[i]):
                    self.node_fea_matrix[i][5] = 1
                else:
                    self.node_fea_matrix[i][5] = 0
            
        else:
            sram_input = 0
            tcam_input = 0
        
        
        node_redunt_t = np.zeros((math.ceil(self.topo_adj_matrix.shape[0]/stage_fea) ,stage_fea))
        count_n = 0
        i_row = 0
        j_col = 0
        while(count_n < self.topo_adj_matrix.shape[0]):
            if(self.node_occu[count_n] == 1):
                node_redunt_t[int(count_n/stage_fea)][count_n%stage_fea] = 1
            count_n = count_n + 1
        
        ob_sfc_info_zero = np.zeros((self.topo_adj_matrix.shape[0]*12+1+math.ceil(self.topo_adj_matrix.shape[0]/stage_fea), self.topo_adj_matrix.shape[0]+ ip_fea-stage_fea))
        #print('self.ob_sfc_info', ob_sfc_info_zero.shape)
        #ob_sfc_info_t = np.concatenate((copy.deepcopy(self.ob_sfc_info), ob_sfc_info_zero), axis=0)
        
        # TCAM SRAM OCCU
        # node_fea part 1
        node_fea_t1 = copy.deepcopy(self.node_fea_matrix.take([0,1,3] ,1))
        # update reward in row 3
        if(type(mask) != int):
            for i in range(node_fea_t1.shape[0]):
                if(mask[i] == 0):
                    node_fea_t1[i][2] = 0
                else:
                    if(self.node_fea_matrix[i][3] == 0 and self.node_occu[i//12] == 0):
                        # stage 0 sw 0
                        node_fea_t1[i][2] = rew1
                    elif(self.node_fea_matrix[i][3] == 0 and self.node_occu[i//12] == 1):
                        # stage 0 sw 1
                        node_fea_t1[i][2] = rew2
                    elif(self.node_fea_matrix[i][3] == 1 and self.node_fea_matrix[i][5] == 0 and self.node_occu[i//12] == 1):
                        # stage 1 sw 1
                        node_fea_t1[i][2] = rew3
                    elif(self.node_fea_matrix[i][5] == 1 and self.node_occu[i//12] == 1):
                        # redunt 1 sw 1
                        node_fea_t1[i][2] = rew4
        
        # node_fea part 2: table info add one row(1,4)
        node_fea_t1 = np.row_stack((node_fea_t1, [sram_input, tcam_input, self.sfc.sfc_bw]))
        # node_fea part 3
        node_fea_t = np.concatenate((node_fea_t1, node_redunt_t), axis=0)
        # lat bw
        ip_fea_temp = copy.deepcopy(self.node_fea_matrix.take([2,4] ,1))
        #print('ip_fea_temp', ip_fea_temp)
        ip_fea_list = [i for i in range(ip_fea_temp.shape[0]) if i % 12 == 0]
        ip_fea_t = ip_fea_temp.take(ip_fea_list ,0)
        
        topo_M = np.concatenate((copy.deepcopy(self.topo_adj_matrix), ip_fea_t), axis=1)
        
        tbl_stage_M = np.concatenate((ob_sfc_info_zero, node_fea_t), axis=1)
        #print('tbl_stage_M', tbl_stage_M)
        obs = np.concatenate((topo_M, tbl_stage_M), axis=0)
        return obs


    def get_redunt_res(self, tbl_num_v, sfc_num_v, tbl_name_v, action):
        stage = action
        sfc_num = sfc_num_v
        tbl_num = tbl_num_v
        error_flag = False
        SFC_input_info_list = self.sfc.get_SFC_input_info_list()
        rel_sfc = 0
        rel_tbl = 0
        while(sfc_num >= 0):
            sfc_num = sfc_num - 1
            for i in range(len(SFC_input_info_list[sfc_num])):
                if(SFC_input_info_list[sfc_num][i][0] == tbl_name_v):
                    rel_sfc = sfc_num
                    rel_tbl = i
                    place_info = self.tbl_rel_record[rel_sfc][rel_tbl]
                    try:
                        res_index = place_info[0::2].index(stage)
                        res = place_info[res_index*2+1]
                        return res
                    except:
                        continue
        if(error_flag == False):
            print('error in redunt table name !!!!!!!!!!!!!!!!!!!')
        return 0


    #############  测试用函数 #####################
    def print_var(self):
        print('##### TOPO情况 #########')
        print('##### tbl存放情况 #########')
        print('tbl_place:,', self.tbl_place)
        print('##### stage的资源使用情况 #########')
        print('self.node_fea_matrix:,', self.node_fea_matrix)
        print('##### ????? #########')
        print('self.topo_adj_matrix:,', self.topo_adj_matrix)
        #print('##### 邻接矩阵 #########')
        #print('self.adj_matrix :,', self.adj_matrix )
        print('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')
        print('')

        

        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
    
